#!/usr/bin/env node

const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Base de données
const db = new sqlite3.Database('./data/gpauto.db');

console.log('🔄 Migration vers la nouvelle structure véhicules/motorisations...');

// Fonction pour attendre une requête
function runAsync(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function(err) {
            if (err) reject(err);
            else resolve(this);
        });
    });
}

function allAsync(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => {
            if (err) reject(err);
            else resolve(rows);
        });
    });
}

async function migrate() {
    try {
        // 1. Créer les nouvelles tables si elles n'existent pas
        console.log('📋 Création des nouvelles tables...');
        
        await runAsync(`
            CREATE TABLE IF NOT EXISTS engines (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                vehicle_id INTEGER NOT NULL,
                engine TEXT NOT NULL,
                fuel_type TEXT NOT NULL,
                FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE CASCADE
            )
        `);
        
        await runAsync(`
            CREATE TABLE IF NOT EXISTS part_vehicle_relations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                part_id INTEGER NOT NULL,
                vehicle_id INTEGER NOT NULL,
                engine_id INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (part_id) REFERENCES parts (id) ON DELETE CASCADE,
                FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE CASCADE,
                FOREIGN KEY (engine_id) REFERENCES engines (id) ON DELETE CASCADE
            )
        `);

        // 2. Migrer les véhicules existants vers la nouvelle structure
        console.log('🚗 Migration des véhicules existants...');
        
        const existingVehicles = await allAsync('SELECT * FROM vehicles');
        
        for (const vehicle of existingVehicles) {
            // Si le véhicule a déjà une motorisation, la migrer
            if (vehicle.engine && vehicle.fuel_type) {
                await runAsync(
                    'INSERT INTO engines (vehicle_id, engine, fuel_type) VALUES (?, ?, ?)',
                    [vehicle.id, vehicle.engine, vehicle.fuel_type]
                );
                console.log(`   ✅ Véhicule ${vehicle.brand} ${vehicle.model}: motorisation migrée`);
            }
        }
        
        // 3. Supprimer les colonnes obsolètes des véhicules (en sécurité)
        console.log('🧹 Nettoyage des colonnes obsolètes...');
        
        // Créer une nouvelle table véhicules sans les colonnes obsolètes
        await runAsync(`
            CREATE TABLE vehicles_new AS 
            SELECT id, brand, model, year_from, year_to 
            FROM vehicles
        `);
        
        // Supprimer l'ancienne table et renommer la nouvelle
        await runAsync('DROP TABLE vehicles');
        await runAsync('ALTER TABLE vehicles_new RENAME TO vehicles');
        
        console.log('   ✅ Colonnes engine et fuel_type supprimées de la table vehicles');
        
        // 4. Migrer les références véhicules des pièces vers la nouvelle relation
        console.log('🔧 Migration des compatibilités pièces...');
        
        const existingParts = await allAsync('SELECT * FROM parts');
        
        for (const part of existingParts) {
            if (part.vehicle_compatibility) {
                try {
                    // Essayer de parser vehicle_compatibility comme JSON
                    const compatibility = JSON.parse(part.vehicle_compatibility);
                    
                    if (Array.isArray(compatibility)) {
                        for (const vehicleId of compatibility) {
                            await runAsync(
                                'INSERT INTO part_vehicle_relations (part_id, vehicle_id) VALUES (?, ?)',
                                [part.id, parseInt(vehicleId)]
                            );
                        }
                    }
                } catch (e) {
                    // Si ce n'est pas du JSON valide, ignorer
                    console.log(`   ⚠️ Pièce ${part.sku}: compatibility non migrée (format invalide)`);
                }
            }
        }
        
        // 5. Supprimer la colonne vehicle_compatibility
        await runAsync(`
            CREATE TABLE parts_new AS 
            SELECT id, name, sku, category, price, description, stock, brand, oe_references, image_url, created_at 
            FROM parts
        `);
        
        await runAsync('DROP TABLE parts');
        await runAsync('ALTER TABLE parts_new RENAME TO parts');
        
        console.log('   ✅ Colonne vehicle_compatibility supprimée de la table parts');
        
        console.log('🎉 Migration terminée avec succès !');
        
        // 6. Afficher les statistiques
        const vehicleCount = await allAsync('SELECT COUNT(*) as count FROM vehicles');
        const engineCount = await allAsync('SELECT COUNT(*) as count FROM engines');
        const relationCount = await allAsync('SELECT COUNT(*) as count FROM part_vehicle_relations');
        
        console.log('\n📊 Statistiques après migration:');
        console.log(`   - Véhicules: ${vehicleCount[0].count}`);
        console.log(`   - Motorisations: ${engineCount[0].count}`);
        console.log(`   - Relations pièces-véhicules: ${relationCount[0].count}`);
        
    } catch (error) {
        console.error('❌ Erreur lors de la migration:', error);
        process.exit(1);
    }
}

// Exécuter la migration
migrate().then(() => {
    console.log('\n✅ La base de données a été migrée avec succès !');
    process.exit(0);
}).catch(error => {
    console.error('\n❌ Échec de la migration:', error);
    process.exit(1);
});