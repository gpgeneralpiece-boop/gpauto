const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../')));

// Base de données SQLite
const db = new sqlite3.Database('./data/gpauto.db');

// Initialisation de la base de données
function initDatabase() {
    db.serialize(() => {
        // Table des véhicules
        db.run(`CREATE TABLE IF NOT EXISTS vehicles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            brand TEXT NOT NULL,
            model TEXT NOT NULL,
            year_from INTEGER,
            year_to INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        // Table des motorisations
        db.run(`CREATE TABLE IF NOT EXISTS engines (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vehicle_id INTEGER NOT NULL,
            engine TEXT NOT NULL,
            fuel_type TEXT NOT NULL,
            FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE CASCADE
        )`);

        // Table relation pièces-véhicules
        db.run(`CREATE TABLE IF NOT EXISTS part_vehicle_relations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            part_id INTEGER NOT NULL,
            vehicle_id INTEGER NOT NULL,
            engine_id INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (part_id) REFERENCES parts (id) ON DELETE CASCADE,
            FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE CASCADE,
            FOREIGN KEY (engine_id) REFERENCES engines (id) ON DELETE CASCADE
        )`);

        // Table des pièces
        db.run(`CREATE TABLE IF NOT EXISTS parts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            sku TEXT UNIQUE NOT NULL,
            category TEXT NOT NULL,
            price REAL NOT NULL,
            description TEXT,
            stock INTEGER DEFAULT 0,
            brand TEXT,
            oe_references TEXT, -- JSON array
            image_url TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        // Table des commandes
        db.run(`CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name TEXT NOT NULL,
            phone TEXT NOT NULL,
            address TEXT,
            delivery_mode TEXT NOT NULL,
            items TEXT NOT NULL, -- JSON
            total_amount REAL NOT NULL,
            delivery_fee REAL DEFAULT 0,
            status TEXT DEFAULT 'pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        // Base de données créée, prête pour les données migrées
    });
}

// Données de démonstration pour la Tunisie
function insertDemoData() {
    const vehicles = [
        // Renault Tunisia
        { brand: 'Renault', model: 'Clio', year_from: 2012, year_to: 2025, engine: '1.2L', fuel_type: 'Essence' },
        { brand: 'Renault', model: 'Megane', year_from: 2014, year_to: 2025, engine: '1.6L', fuel_type: 'Essence' },
        { brand: 'Renault', model: 'Kangoo', year_from: 2016, year_to: 2025, engine: '1.5L', fuel_type: 'Diesel' },
        { brand: 'Renault', model: 'Symbol', year_from: 2013, year_to: 2025, engine: '1.4L', fuel_type: 'Essence' },
        
        // Peugeot Tunisia
        { brand: 'Peugeot', model: '208', year_from: 2015, year_to: 2025, engine: '1.2L', fuel_type: 'Essence' },
        { brand: 'Peugeot', model: '308', year_from: 2013, year_to: 2025, engine: '1.6L', fuel_type: 'Essence' },
        { brand: 'Peugeot', model: 'Partner', year_from: 2014, year_to: 2025, engine: '1.6L', fuel_type: 'Diesel' },
        { brand: 'Peugeot', model: '206', year_from: 2008, year_to: 2015, engine: '1.4L', fuel_type: 'Essence' },
        
        // Citroën Tunisia
        { brand: 'Citroën', model: 'C3', year_from: 2014, year_to: 2025, engine: '1.2L', fuel_type: 'Essence' },
        { brand: 'Citroën', model: 'C4', year_from: 2012, year_to: 2025, engine: '1.6L', fuel_type: 'Essence' },
        { brand: 'Citroën', model: 'Berlingo', year_from: 2015, year_to: 2025, engine: '1.6L', fuel_type: 'Diesel' },
        
        // Dacia Tunisia (très populaire)
        { brand: 'Dacia', model: 'Logan', year_from: 2010, year_to: 2025, engine: '1.4L', fuel_type: 'Essence' },
        { brand: 'Dacia', model: 'Sandero', year_from: 2012, year_to: 2025, engine: '1.2L', fuel_type: 'Essence' },
        { brand: 'Dacia', model: 'Duster', year_from: 2013, year_to: 2025, engine: '1.6L', fuel_type: 'Essence' },
        { brand: 'Dacia', model: 'Lodgy', year_from: 2015, year_to: 2025, engine: '1.5L', fuel_type: 'Diesel' },
        
        // Autres marques populaires en Tunisie
        { brand: 'Hyundai', model: 'i10', year_from: 2014, year_to: 2025, engine: '1.2L', fuel_type: 'Essence' },
        { brand: 'Hyundai', model: 'i20', year_from: 2015, year_to: 2025, engine: '1.4L', fuel_type: 'Essence' },
        { brand: 'Kia', model: 'Picanto', year_from: 2014, year_to: 2025, engine: '1.0L', fuel_type: 'Essence' },
        { brand: 'Kia', model: 'Rio', year_from: 2015, year_to: 2025, engine: '1.4L', fuel_type: 'Essence' },
        { brand: 'Fiat', model: 'Punto', year_from: 2010, year_to: 2018, engine: '1.4L', fuel_type: 'Essence' },
        { brand: 'Volkswagen', model: 'Golf', year_from: 2011, year_to: 2025, engine: '1.4L', fuel_type: 'Essence' }
    ];

    const parts = [
        // Système de frein
        { 
            name: 'Plaquettes de frein avant', 
            sku: 'PF-001', 
            category: 'Freinage', 
            price: 107.97, 
            description: 'Plaquettes de frein avant compatibles diverses marques',
            stock: 25,
            brand: 'Textar',
            vehicle_compatibility: 'Universel',
            oe_references: JSON.stringify(['1609253180', '1609253980', '425086', '8K0698151A']),
            image_url: 'https://via.placeholder.com/300x200/1F4F5A/white?text=Plaquettes+Frein'
        },
        { 
            name: 'Disque de frein avant', 
            sku: 'DF-001', 
            category: 'Freinage', 
            price: 215.85, 
            description: 'Disque de frein avant ventilation',
            stock: 15,
            brand: 'Brembo',
            vehicle_compatibility: 'Universel',
            oe_references: JSON.stringify(['1J0615301AA', '1J0615301AB']),
            image_url: 'https://via.placeholder.com/300x200/1F4F5A/white?text=Disque+Frein'
        },
        
        // Filtration
        { 
            name: 'Filtre à huile', 
            sku: 'FH-001', 
            category: 'Filtration', 
            price: 32.10, 
            description: 'Filtre à huile moteur haute qualité',
            stock: 50,
            brand: 'Mann',
            vehicle_compatibility: 'Universel',
            oe_references: JSON.stringify(['15400PLMA01', '15400-PLM-A01']),
            image_url: 'https://via.placeholder.com/300x200/1F4F5A/white?text=Filtre+Huile'
        },
        { 
            name: 'Filtre à air', 
            sku: 'FA-001', 
            category: 'Filtration', 
            price: 48.15, 
            description: 'Filtre à air moteur performance',
            stock: 35,
            brand: 'K&N',
            vehicle_compatibility: 'Universel',
            oe_references: JSON.stringify(['1780125010', '17801-25010']),
            image_url: 'https://via.placeholder.com/300x200/1F4F5A/white?text=Filtre+Air'
        },
        { 
            name: 'Filtre carburant', 
            sku: 'FC-001', 
            category: 'Filtration', 
            price: 64.20, 
            description: 'Filtre carburant diesel/essence',
            stock: 28,
            brand: 'Bosch',
            vehicle_compatibility: 'Universel',
            oe_references: JSON.stringify(['1457434332', '0580252044']),
            image_url: 'https://via.placeholder.com/300x200/1F4F5A/white?text=Filtre+Carburant'
        },
        
        // Allumage
        { 
            name: 'Bougies d\'allumage (4 pièces)', 
            sku: 'BA-001', 
            category: 'Allumage', 
            price: 96.30, 
            description: 'Jeux de bougies d\'allumage iridium',
            stock: 40,
            brand: 'NGK',
            vehicle_compatibility: 'Universel',
            oe_references: JSON.stringify(['90919012457', '90919-01245']),
            image_url: 'https://via.placeholder.com/300x200/1F4F5A/white?text=Bougies'
        },
        
        // Suspension
        { 
            name: 'Amortisseurs avant (2 pièces)', 
            sku: 'AM-001', 
            category: 'Suspension', 
            price: 429.75, 
            description: 'Amortisseurs avant performance',
            stock: 20,
            brand: 'KYB',
            vehicle_compatibility: 'Universel',
            oe_references: JSON.stringify(['334381', '334382']),
            image_url: 'https://via.placeholder.com/300x200/1F4F5A/white?text=Amortisseurs'
        },
        
        // Électrique
        { 
            name: 'Batterie 12V 60Ah', 
            sku: 'BT-001', 
            category: 'Électrique', 
            price: 321.00, 
            description: 'Batterie démarrage longue durée',
            stock: 12,
            brand: 'Varta',
            vehicle_compatibility: 'Universel',
            oe_references: JSON.stringify(['5604080547152', 'L2-400']),
            image_url: 'https://via.placeholder.com/300x200/1F4F5A/white?text=Batterie'
        },
        
        // Carrosserie
        { 
            name: 'Pare-chocs avant', 
            sku: 'PC-001', 
            category: 'Carrosserie', 
            price: 642.00, 
            description: 'Pare-chocs avant neuf',
            stock: 8,
            brand: 'OEM',
            vehicle_compatibility: 'Renault Clio 2012-2015',
            oe_references: JSON.stringify(['8200575063', '8200575064']),
            image_url: 'https://via.placeholder.com/300x200/1F4F5A/white?text=Pare-chocs'
        },
        
        // Pneumatiques (référence)
        { 
            name: 'Pneumatiques 185/65 R15', 
            sku: 'PN-001', 
            category: 'Pneumatiques', 
            price: 160.50, 
            description: 'Jeu de 4 pneumatiques été',
            stock: 30,
            brand: 'Michelin',
            vehicle_compatibility: 'Universel 15 pouces',
            oe_references: JSON.stringify(['3528701234567']),
            image_url: 'https://via.placeholder.com/300x200/1F4F5A/white?text=Pneumatiques'
        }
    ];

    // Insertion des véhicules
    const vehicleStmt = db.prepare('INSERT OR REPLACE INTO vehicles (brand, model, year_from, year_to, engine, fuel_type) VALUES (?, ?, ?, ?, ?, ?)');
    vehicles.forEach(vehicle => {
        vehicleStmt.run([vehicle.brand, vehicle.model, vehicle.year_from, vehicle.year_to, vehicle.engine, vehicle.fuel_type]);
    });
    vehicleStmt.finalize();

    // Insertion des pièces
    const partStmt = db.prepare('INSERT OR REPLACE INTO parts (name, sku, category, price, description, stock, brand, vehicle_compatibility, oe_references, image_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    parts.forEach(part => {
        partStmt.run([part.name, part.sku, part.category, part.price, part.description, part.stock, part.brand, part.vehicle_compatibility, part.oe_references, part.image_url]);
    });
    partStmt.finalize();
}

// ================================
// ROUTES CRUD POUR L'ADMIN
// ================================

// Routes CRUD pour les véhicules
app.post('/api/vehicles', (req, res) => {
    const { brand, model, year_from, year_to, engines } = req.body;
    
    // Validation
    if (!brand || !model || !engines || !Array.isArray(engines) || engines.length === 0) {
        return res.status(400).json({ error: 'Marque, modèle et au moins une motorisation sont obligatoires' });
    }
    
    // Validation des motorisations
    for (let engine of engines) {
        if (!engine.engine || !engine.fuel_type) {
            return res.status(400).json({ error: 'Chaque motorisation doit avoir une désignation et un carburant' });
        }
    }
    
    // Transaction pour créer le véhicule et ses motorisations
    db.serialize(() => {
        db.run('BEGIN TRANSACTION');
        
        // Créer le véhicule
        const vehicleQuery = `INSERT INTO vehicles (brand, model, year_from, year_to) VALUES (?, ?, ?, ?)`;
        db.run(vehicleQuery, [brand, model, year_from, year_to], function(err) {
            if (err) {
                db.run('ROLLBACK');
                res.status(500).json({ error: err.message });
                return;
            }
            
            const vehicleId = this.lastID;
            
            // Insérer les motorisations
            let completed = 0;
            let hasError = false;
            
            engines.forEach(engine => {
                const engineQuery = `INSERT INTO engines (vehicle_id, engine, fuel_type) VALUES (?, ?, ?)`;
                db.run(engineQuery, [vehicleId, engine.engine, engine.fuel_type], function(err) {
                    if (err && !hasError) {
                        hasError = true;
                        db.run('ROLLBACK');
                        res.status(500).json({ error: 'Erreur lors de la création des motorisations: ' + err.message });
                        return;
                    }
                    
                    completed++;
                    if (completed === engines.length && !hasError) {
                        db.run('COMMIT', (err) => {
                            if (err) {
                                db.run('ROLLBACK');
                                res.status(500).json({ error: err.message });
                                return;
                            }
                            
                            res.json({ 
                                success: true, 
                                vehicle_id: vehicleId,
                                message: 'Véhicule créé avec succès avec ' + engines.length + ' motorisation(s)' 
                            });
                        });
                    }
                });
            });
        });
    });
});

app.put('/api/vehicles/:id', (req, res) => {
    const { id } = req.params;
    const { brand, model, year_from, year_to, engines } = req.body;
    
    // Validation
    if (!brand || !model || !engines || !Array.isArray(engines) || engines.length === 0) {
        return res.status(400).json({ error: 'Marque, modèle et au moins une motorisation sont obligatoires' });
    }
    
    // Validation des motorisations
    for (let engine of engines) {
        if (!engine.engine || !engine.fuel_type) {
            return res.status(400).json({ error: 'Chaque motorisation doit avoir une désignation et un carburant' });
        }
    }
    
    // Transaction pour mettre à jour le véhicule et ses motorisations
    db.serialize(() => {
        db.run('BEGIN TRANSACTION');
        
        // Mettre à jour le véhicule
        const vehicleQuery = `UPDATE vehicles SET brand = ?, model = ?, year_from = ?, year_to = ? WHERE id = ?`;
        db.run(vehicleQuery, [brand, model, year_from, year_to, id], function(err) {
            if (err) {
                db.run('ROLLBACK');
                res.status(500).json({ error: err.message });
                return;
            }
            
            if (this.changes === 0) {
                db.run('ROLLBACK');
                res.status(404).json({ error: 'Véhicule non trouvé' });
                return;
            }
            
            // Supprimer les anciennes motorisations
            db.run('DELETE FROM engines WHERE vehicle_id = ?', [id], function(err) {
                if (err) {
                    db.run('ROLLBACK');
                    res.status(500).json({ error: err.message });
                    return;
                }
                
                // Insérer les nouvelles motorisations
                let completed = 0;
                let hasError = false;
                
                engines.forEach(engine => {
                    const engineQuery = `INSERT INTO engines (vehicle_id, engine, fuel_type) VALUES (?, ?, ?)`;
                    db.run(engineQuery, [id, engine.engine, engine.fuel_type], function(err) {
                        if (err && !hasError) {
                            hasError = true;
                            db.run('ROLLBACK');
                            res.status(500).json({ error: 'Erreur lors de la mise à jour des motorisations: ' + err.message });
                            return;
                        }
                        
                        completed++;
                        if (completed === engines.length && !hasError) {
                            db.run('COMMIT', (err) => {
                                if (err) {
                                    db.run('ROLLBACK');
                                    res.status(500).json({ error: err.message });
                                    return;
                                }
                                
                                res.json({ 
                                    success: true, 
                                    message: 'Véhicule mis à jour avec succès avec ' + engines.length + ' motorisation(s)' 
                                });
                            });
                        }
                    });
                });
            });
        });
    });
});

app.delete('/api/vehicles/:id', (req, res) => {
    const { id } = req.params;
    
    const query = 'DELETE FROM vehicles WHERE id = ?';
    
    db.run(query, [id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        if (this.changes === 0) {
            return res.status(404).json({ error: 'Véhicule non trouvé' });
        }
        
        res.json({ 
            success: true, 
            message: 'Véhicule supprimé avec succès' 
        });
    });
});

// Routes CRUD pour les pièces
app.post('/api/parts', (req, res) => {
    const { name, sku, category, price, description, stock, brand, vehicle_ids, engine_ids, oe_references, image_url } = req.body;
    
    // Validation
    if (!name || !sku || !category || price === undefined || stock === undefined) {
        return res.status(400).json({ error: 'Nom, SKU, catégorie, prix et stock sont obligatoires' });
    }
    
    // Transaction pour créer la pièce et ses relations
    db.serialize(() => {
        db.run('BEGIN TRANSACTION');
        
        // Créer la pièce
        const partQuery = `INSERT INTO parts (name, sku, category, price, description, stock, brand, oe_references, image_url) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;
        
        db.run(partQuery, [
            name, sku, category, price, description, stock, brand, 
            JSON.stringify(oe_references || []), image_url
        ], function(err) {
            if (err) {
                db.run('ROLLBACK');
                if (err.message.includes('UNIQUE constraint failed')) {
                    res.status(400).json({ error: 'Ce SKU existe déjà' });
                } else {
                    res.status(500).json({ error: err.message });
                }
                return;
            }
            
            const partId = this.lastID;
            
            // Si des véhicules sont spécifiés, créer les relations
            if (vehicle_ids && Array.isArray(vehicle_ids) && vehicle_ids.length > 0) {
                let completed = 0;
                let hasError = false;
                
                vehicle_ids.forEach((vehicle_id, index) => {
                    const engine_id = engine_ids && engine_ids[index] ? engine_ids[index] : null;
                    
                    const relationQuery = `INSERT INTO part_vehicle_relations (part_id, vehicle_id, engine_id) VALUES (?, ?, ?)`;
                    db.run(relationQuery, [partId, vehicle_id, engine_id], function(err) {
                        if (err && !hasError) {
                            hasError = true;
                            db.run('ROLLBACK');
                            res.status(500).json({ error: 'Erreur lors de la création des relations: ' + err.message });
                            return;
                        }
                        
                        completed++;
                        if (completed === vehicle_ids.length && !hasError) {
                            db.run('COMMIT', (err) => {
                                if (err) {
                                    db.run('ROLLBACK');
                                    res.status(500).json({ error: err.message });
                                    return;
                                }
                                
                                res.json({ 
                                    success: true, 
                                    id: partId,
                                    message: 'Pièce créée avec succès et liée à ' + vehicle_ids.length + ' véhicule(s)' 
                                });
                            });
                        }
                    });
                });
            } else {
                // Pas de véhicules spécifiés
                db.run('COMMIT', (err) => {
                    if (err) {
                        db.run('ROLLBACK');
                        res.status(500).json({ error: err.message });
                        return;
                    }
                    
                    res.json({ 
                        success: true, 
                        id: partId,
                        message: 'Pièce créée avec succès' 
                    });
                });
            }
        });
    });
});

app.put('/api/parts/:id', (req, res) => {
    const { id } = req.params;
    const { name, sku, category, price, description, stock, brand, vehicle_compatibility, oe_references, image_url } = req.body;
    
    // Validation
    if (!name || !sku || !category || price === undefined || stock === undefined) {
        return res.status(400).json({ error: 'Nom, SKU, catégorie, prix et stock sont obligatoires' });
    }
    
    const query = `UPDATE parts 
                   SET name = ?, sku = ?, category = ?, price = ?, description = ?, stock = ?, 
                       brand = ?, vehicle_compatibility = ?, oe_references = ?, image_url = ?
                   WHERE id = ?`;
    
    db.run(query, [
        name, sku, category, price, description, stock, brand, 
        vehicle_compatibility, JSON.stringify(oe_references || []), image_url, id
    ], function(err) {
        if (err) {
            if (err.message.includes('UNIQUE constraint failed')) {
                res.status(400).json({ error: 'Ce SKU existe déjà' });
            } else {
                res.status(500).json({ error: err.message });
            }
            return;
        }
        
        if (this.changes === 0) {
            return res.status(404).json({ error: 'Pièce non trouvée' });
        }
        
        res.json({ 
            success: true, 
            message: 'Pièce mise à jour avec succès' 
        });
    });
});

app.delete('/api/parts/:sku', (req, res) => {
    const { sku } = req.params;
    
    const query = 'DELETE FROM parts WHERE sku = ?';
    
    db.run(query, [sku], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        if (this.changes === 0) {
            return res.status(404).json({ error: 'Pièce non trouvée' });
        }
        
        res.json({ 
            success: true, 
            message: 'Pièce supprimée avec succès' 
        });
    });
});

// Route pour mettre à jour le statut d'une commande
app.patch('/api/orders/:id', (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    
    // Validation du statut
    const validStatuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
    if (!validStatuses.includes(status)) {
        return res.status(400).json({ error: 'Statut invalide' });
    }
    
    const query = 'UPDATE orders SET status = ? WHERE id = ?';
    
    db.run(query, [status, id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        if (this.changes === 0) {
            return res.status(404).json({ error: 'Commande non trouvée' });
        }
        
        res.json({ 
            success: true, 
            message: 'Statut mis à jour avec succès' 
        });
    });
});

// ================================
// ROUTES PRINCIPALES
// ================================

// Routes API

// 1. Obtenir tous les véhicules avec filtres
app.get('/api/vehicles', (req, res) => {
    const { brand, model, engine, fuel_type } = req.query;
    
    let query = `
        SELECT 
            v.id, v.brand, v.model, v.year_from, v.year_to, v.created_at,
            e.id as engine_id, e.engine, e.fuel_type
        FROM vehicles v 
        LEFT JOIN engines e ON v.id = e.vehicle_id
    `;
    
    const conditions = [];
    const params = [];
    
    if (brand) {
        conditions.push('v.brand = ?');
        params.push(brand);
    }
    if (model) {
        conditions.push('v.model = ?');
        params.push(model);
    }
    if (engine) {
        conditions.push('e.engine = ?');
        params.push(engine);
    }
    if (fuel_type) {
        conditions.push('e.fuel_type = ?');
        params.push(fuel_type);
    }
    
    if (conditions.length > 0) {
        query += ' WHERE ' + conditions.join(' AND ');
    }
    
    query += ' ORDER BY v.brand, v.model, e.engine';
    
    db.all(query, params, (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        // Grouper par véhicule
        const vehiclesMap = new Map();
        
        rows.forEach(row => {
            if (!vehiclesMap.has(row.id)) {
                vehiclesMap.set(row.id, {
                    id: row.id,
                    brand: row.brand,
                    model: row.model,
                    year_from: row.year_from,
                    year_to: row.year_to,
                    engines: []
                });
            }
            
            // Ajouter la motorisation si elle existe
            if (row.engine_id) {
                vehiclesMap.get(row.id).engines.push({
                    id: row.engine_id,
                    engine: row.engine,
                    fuel_type: row.fuel_type
                });
            }
        });
        
        res.json(Array.from(vehiclesMap.values()));
    });
});

// 2. Obtenir les motorisations pour une marque/modèle
app.get('/api/vehicles/engines', (req, res) => {
    const { brand, model } = req.query;
    const query = 'SELECT DISTINCT engine, fuel_type FROM vehicles WHERE brand = ? AND model = ? ORDER BY engine';
    
    db.all(query, [brand, model], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// 3. Obtenir les pièces par véhicule
app.get('/api/parts/vehicle/:brand/:model/:engine', (req, res) => {
    const { brand, model, engine } = req.params;
    const query = 'SELECT * FROM parts WHERE vehicle_compatibility LIKE ? OR vehicle_compatibility = "Universel" ORDER BY category, name';
    
    const compatibility = `%${brand}%${model}%`;
    db.all(query, [compatibility], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        // Parser les références OE
        const parts = rows.map(part => ({
            ...part,
            oe_references: JSON.parse(part.oe_references || '[]')
        }));
        
        res.json(parts);
    });
});

// 4. Obtenir toutes les pièces par catégorie
app.get('/api/parts/category/:category', (req, res) => {
    const { category } = req.params;
    const query = 'SELECT * FROM parts WHERE category = ? ORDER BY name';
    
    db.all(query, [category], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        const parts = rows.map(part => ({
            ...part,
            oe_references: JSON.parse(part.oe_references || '[]')
        }));
        
        res.json(parts);
    });
});

// 5. Recherche multi-critères
app.get('/api/search', (req, res) => {
    const { query } = req.query;
    
    if (!query || query.length < 2) {
        return res.json([]);
    }
    
    const searchQuery = `%${query}%`;
    const dbQuery = `
        SELECT * FROM parts 
        WHERE name LIKE ? 
           OR sku LIKE ? 
           OR category LIKE ? 
           OR brand LIKE ? 
           OR vehicle_compatibility LIKE ?
           OR oe_references LIKE ?
        ORDER BY 
            CASE 
                WHEN name LIKE ? THEN 1
                WHEN sku LIKE ? THEN 2
                WHEN category LIKE ? THEN 3
                ELSE 4
            END,
            name
        LIMIT 50
    `;
    
    const params = [
        searchQuery, searchQuery, searchQuery, searchQuery, searchQuery, searchQuery,
        query, query, query
    ];
    
    db.all(dbQuery, params, (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        const parts = rows.map(part => ({
            ...part,
            oe_references: JSON.parse(part.oe_references || '[]')
        }));
        
        res.json(parts);
    });
});

// 4. Liste des véhicules pour l'admin (avec motorisations)
app.get('/api/admin/vehicles', (req, res) => {
    const query = `
        SELECT 
            v.id, v.brand, v.model, v.year_from, v.year_to,
            e.id as engine_id, e.engine, e.fuel_type,
            COUNT(DISTINCT pvr.part_id) as compatible_parts_count
        FROM vehicles v 
        LEFT JOIN engines e ON v.id = e.vehicle_id
        LEFT JOIN part_vehicle_relations pvr ON v.id = pvr.vehicle_id
        GROUP BY v.id, e.id
        ORDER BY v.brand, v.model, e.engine
    `;
    
    db.all(query, [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        // Grouper par véhicule
        const vehiclesMap = new Map();
        
        rows.forEach(row => {
            if (!vehiclesMap.has(row.id)) {
                vehiclesMap.set(row.id, {
                    id: row.id,
                    brand: row.brand,
                    model: row.model,
                    year_from: row.year_from,
                    year_to: row.year_to,
                    engines: [],
                    compatible_parts_count: row.compatible_parts_count || 0
                });
            }
            
            // Ajouter la motorisation si elle existe
            if (row.engine_id) {
                vehiclesMap.get(row.id).engines.push({
                    id: row.engine_id,
                    engine: row.engine,
                    fuel_type: row.fuel_type
                });
            }
        });
        
        res.json(Array.from(vehiclesMap.values()));
    });
});

// 5. Obtenir toutes les catégories
app.get('/api/categories', (req, res) => {
    const query = 'SELECT DISTINCT category FROM parts ORDER BY category';
    
    db.all(query, [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// 6b. Obtenir toutes les commandes
app.get('/api/orders', (req, res) => {
    const query = 'SELECT * FROM orders ORDER BY created_at DESC';
    
    db.all(query, [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        const orders = rows.map(order => ({
            ...order,
            items: JSON.parse(order.items || '[]')
        }));
        
        res.json(orders);
    });
});

// 7. Créer une commande
app.post('/api/orders', (req, res) => {
    const { customer_name, phone, address, delivery_mode, items, total_amount, delivery_fee } = req.body;
    
    const query = `INSERT INTO orders (customer_name, phone, address, delivery_mode, items, total_amount, delivery_fee) 
                   VALUES (?, ?, ?, ?, ?, ?, ?)`;
    
    db.run(query, [
        customer_name, phone, address, delivery_mode, JSON.stringify(items), total_amount, delivery_fee
    ], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ 
            success: true, 
            order_id: this.lastID,
            message: 'Commande créée avec succès' 
        });
    });
});

// 8. Obtenir une commande
app.get('/api/orders/:id', (req, res) => {
    const { id } = req.params;
    const query = 'SELECT * FROM orders WHERE id = ?';
    
    db.get(query, [id], (err, row) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        if (!row) {
            return res.status(404).json({ error: 'Commande non trouvée' });
        }
        
        row.items = JSON.parse(row.items || '[]');
        res.json(row);
    });
});

// 9. Statistiques simples
app.get('/api/stats', (req, res) => {
    const queries = [
        'SELECT COUNT(*) as total_parts FROM parts',
        'SELECT COUNT(*) as total_orders FROM orders',
        'SELECT COUNT(DISTINCT brand) as total_brands FROM vehicles',
        'SELECT category, COUNT(*) as count FROM parts GROUP BY category ORDER BY count DESC LIMIT 5'
    ];
    
    Promise.all(queries.map(query => new Promise((resolve, reject) => {
        db.get(query, [], (err, row) => {
            if (err) reject(err);
            else resolve(row);
        });
    }))).then(results => {
        res.json({
            total_parts: results[0].total_parts,
            total_orders: results[1].total_orders,
            total_brands: results[2].total_brands,
            top_categories: results[3]
        });
    }).catch(err => {
        res.status(500).json({ error: err.message });
    });
});

// Route de santé
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'OK', 
        message: 'GP AUTO Backend fonctionne parfaitement',
        timestamp: new Date().toISOString()
    });
});

// Middleware pour les erreurs 404
app.use('*', (req, res) => {
    res.status(404).json({ 
        error: 'Endpoint non trouvé',
        available_endpoints: [
            // Health & Stats
            'GET /api/health',
            'GET /api/stats',
            
            // Vehicles CRUD
            'GET /api/vehicles',
            'GET /api/vehicles?brand=...',
            'GET /api/vehicles/engines?brand=...&model=...',
            'POST /api/vehicles',
            'PUT /api/vehicles/:id',
            'DELETE /api/vehicles/:id',
            
            // Parts CRUD
            'GET /api/parts/vehicle/:brand/:model/:engine',
            'GET /api/parts/category/:category',
            'GET /api/search?query=...',
            'POST /api/parts',
            'PUT /api/parts/:id',
            'DELETE /api/parts/:sku',
            'GET /api/categories',
            
            // Orders
            'GET /api/orders',
            'POST /api/orders',
            'GET /api/orders/:id',
            'PATCH /api/orders/:id'
        ]
    });
});

// Initialisation et démarrage
initDatabase();

app.listen(PORT, () => {
    console.log(`🚀 GP AUTO Backend démarré sur le port ${PORT}`);
    console.log(`📊 Base de données initialisée`);
    console.log(`🔗 APIs principales:`);
    console.log(`   - GET /api/health - Santé du serveur`);
    console.log(`   - GET /api/stats - Statistiques`);
    console.log(`   - GET/POST/PUT/DELETE /api/vehicles - CRUD Véhicules (avec motorisations multiples)`);
    console.log(`   - GET /api/admin/vehicles - Liste véhicules pour admin`);
    console.log(`   - GET/POST/PUT/DELETE /api/parts - CRUD Pièces (avec relations véhicules)`);
    console.log(`   - GET/POST/PATCH /api/orders - Gestion Commandes`);
    console.log(`   - GET /api/search - Recherche avancée`);
    console.log(`\n🎛️ Panel Admin disponible: /admin.html`);
    console.log(`🌟 Backend + Panel Admin prêts pour production !`);
});