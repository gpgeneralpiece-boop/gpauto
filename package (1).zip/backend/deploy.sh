#!/bin/bash

# GP AUTO - Script de déploiement backend automatique
# Usage: ./deploy.sh

echo "🚀 Déploiement GP AUTO Backend"
echo "================================"

# 1. Vérification Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js non installé. Veuillez l'installer d'abord:"
    echo "   https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js $(node --version) détecté"

# 2. Installation des dépendances
echo "📦 Installation des dépendances..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ Échec de l'installation des dépendances"
    exit 1
fi

# 3. Création du dossier data
mkdir -p data

# 4. Test de démarrage
echo "🔧 Test de démarrage du serveur..."
timeout 5s npm start &
SERVER_PID=$!

sleep 2

# Test de santé
if curl -s http://localhost:3001/api/health > /dev/null; then
    echo "✅ Backend fonctionne parfaitement !"
    
    # Affichage des statistiques
    echo ""
    echo "📊 Statistiques GP AUTO:"
    curl -s http://localhost:3001/api/stats | python3 -m json.tool 2>/dev/null || echo "   API backend opérationnelle"
else
    echo "⚠️  Serveur en cours de démarrage..."
fi

# Arrêt du serveur de test
kill $SERVER_PID 2>/dev/null

# 5. Instructions de déploiement
echo ""
echo "🎉 Configuration terminée !"
echo ""
echo "📋 COMMANDES DISPONIBLES:"
echo "   npm start        - Démarrer le serveur"
echo "   npm run dev      - Mode développement (auto-reload)"
echo "   npm test         - Tests backend"
echo ""
echo "🌐 URLs API GP AUTO:"
echo "   http://localhost:3001/api/health      - Santé du serveur"
echo "   http://localhost:3001/api/vehicles    - Véhicules"
echo "   http://localhost:3001/api/parts/*     - Catalogue"
echo "   http://localhost:3001/api/search      - Recherche"
echo ""
echo "🚀 DÉPLOIEMENT RECOMMANDÉ:"
echo ""
echo "1. VERCEL (Gratuit):"
echo "   - Créez un compte sur vercel.com"
echo "   - Connectez votre repo GitHub"
echo "   - Vercel détectera automatiquement le backend"
echo ""
echo "2. RAILWAY (Gratuit):"
echo "   - railway.app"
echo "   - Connectez votre repo"
echo "   - Déploiement automatique"
echo ""
echo "3. HEROKU (Payant):"
echo "   - heroku.com"
echo "   - heroku create gp-auto-backend"
echo "   - git push heroku main"
echo ""
echo "💡 Pour connecter au frontend:"
echo "   - Remplacez les données JSON par des appels API"
echo "   - URL backend: votre-url-heroku.railway.app"
echo "   - Exemple: fetch('https://gp-auto-backend.railway.app/api/vehicles')"
echo ""
echo "✨ Backend GP AUTO prêt pour la production !"