const express = require('express');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');

const app = express();
const PORT = process.env.PORT || 3000;

// Configuration Supabase
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error('❌ Missing Supabase configuration');
    console.error('Please set SUPABASE_URL and SUPABASE_ANON_KEY environment variables');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

app.use(cors());
app.use(express.json());

// Middleware de logging
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
});

// 🏥 Health Check
app.get('/api/health', async (req, res) => {
    try {
        // Test de connexion base de données
        const { data, error } = await supabase
            .from('vehicles')
            .select('count', { count: 'exact' })
            .limit(1);
            
        if (error) {
            console.error('Supabase connection error:', error);
            res.status(500).json({ 
                status: 'ERROR', 
                message: 'Database connection failed',
                timestamp: new Date().toISOString()
            });
            return;
        }
        
        res.json({ 
            status: 'OK', 
            message: 'GP Auto API Server running with Supabase',
            timestamp: new Date().toISOString(),
            database: 'supabase',
            environment: process.env.NODE_ENV || 'development'
        });
    } catch (error) {
        console.error('Health check error:', error);
        res.status(500).json({ 
            status: 'ERROR', 
            message: 'Server health check failed',
            timestamp: new Date().toISOString()
        });
    }
});

// 🚗 Vehicle Routes

// GET /api/admin/vehicles - Liste tous les véhicules avec leurs motorisations
app.get('/api/admin/vehicles', async (req, res) => {
    try {
        console.log('Fetching vehicles from Supabase...');
        
        // Récupérer véhicules avec leurs motorisations via JOIN
        const { data: vehicles, error } = await supabase
            .from('vehicles')
            .select(`
                id,
                brand,
                model,
                year_from,
                year_to,
                engines (
                    id,
                    engine,
                    fuel_type
                )
            `)
            .order('brand', { ascending: true });
            
        if (error) {
            console.error('Supabase error:', error);
            res.status(500).json({ error: 'Failed to fetch vehicles from database' });
            return;
        }
        
        console.log(`Found ${vehicles.length} vehicles`);
        
        // Grouper les résultats par véhicule
        const vehiclesMap = new Map();
        vehicles.forEach(vehicle => {
            if (!vehiclesMap.has(vehicle.id)) {
                vehiclesMap.set(vehicle.id, {
                    id: vehicle.id,
                    brand: vehicle.brand,
                    model: vehicle.model,
                    year_from: vehicle.year_from,
                    year_to: vehicle.year_to,
                    engines: []
                });
            }
            
            // Ajouter les motorisations si elles existent
            if (vehicle.engines && vehicle.engines.length > 0) {
                vehicle.engines.forEach(engine => {
                    vehiclesMap.get(vehicle.id).engines.push(engine);
                });
            }
        });
        
        const result = Array.from(vehiclesMap.values());
        console.log(`Returning ${result.length} vehicles with engines`);
        res.json(result);
        
    } catch (error) {
        console.error('Error fetching vehicles:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// POST /api/vehicles - Créer un véhicule avec motorisations multiples
app.post('/api/vehicles', async (req, res) => {
    const { brand, model, year_from, year_to, engines } = req.body;
    
    try {
        console.log('Creating vehicle:', { brand, model, engines: engines?.length });
        
        // Validation
        if (!brand || !model || !engines || engines.length === 0) {
            res.status(400).json({ 
                error: 'Missing required fields: brand, model, engines' 
            });
            return;
        }
        
        // Créer le véhicule
        const { data: vehicle, error: vehicleError } = await supabase
            .from('vehicles')
            .insert({ 
                brand: brand.trim(), 
                model: model.trim(), 
                year_from: year_from || null, 
                year_to: year_to || null 
            })
            .select()
            .single();
            
        if (vehicleError) {
            console.error('Vehicle creation error:', vehicleError);
            res.status(500).json({ error: 'Failed to create vehicle' });
            return;
        }
        
        console.log('Vehicle created with ID:', vehicle.id);
        
        // Préparer les données des motorisations
        const enginesData = engines.map(engine => ({
            vehicle_id: vehicle.id,
            engine: engine.engine.trim(),
            fuel_type: engine.fuel_type
        }));
        
        // Créer les motorisations
        const { error: enginesError } = await supabase
            .from('engines')
            .insert(enginesData);
            
        if (enginesError) {
            console.error('Engines creation error:', enginesError);
            // Tenter de supprimer le véhicule créé
            await supabase.from('vehicles').delete().eq('id', vehicle.id);
            res.status(500).json({ error: 'Failed to create engines' });
            return;
        }
        
        console.log(`Created ${engines.length} engines for vehicle ${vehicle.id}`);
        
        res.json({ 
            success: true, 
            vehicle_id: vehicle.id, 
            engines_count: engines.length,
            message: `Véhicule créé avec ${engines.length} motorisation(s)`
        });
        
    } catch (error) {
        console.error('Unexpected error creating vehicle:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// PUT /api/vehicles/:id - Modifier un véhicule et ses motorisations
app.put('/api/vehicles/:id', async (req, res) => {
    const { id } = req.params;
    const { brand, model, year_from, year_to, engines } = req.body;
    
    try {
        console.log('Updating vehicle:', id, { brand, model, engines: engines?.length });
        
        // Vérifier que le véhicule existe
        const { data: existing, error: checkError } = await supabase
            .from('vehicles')
            .select('id')
            .eq('id', id)
            .single();
            
        if (checkError || !existing) {
            res.status(404).json({ error: 'Vehicle not found' });
            return;
        }
        
        // Mettre à jour le véhicule
        const { error: updateError } = await supabase
            .from('vehicles')
            .update({ 
                brand: brand?.trim(), 
                model: model?.trim(), 
                year_from: year_from || null, 
                year_to: year_to || null 
            })
            .eq('id', id);
            
        if (updateError) {
            console.error('Vehicle update error:', updateError);
            res.status(500).json({ error: 'Failed to update vehicle' });
            return;
        }
        
        // Supprimer les anciennes motorisations
        const { error: deleteError } = await supabase
            .from('engines')
            .delete()
            .eq('vehicle_id', id);
            
        if (deleteError) {
            console.error('Engines delete error:', deleteError);
            res.status(500).json({ error: 'Failed to update engines' });
            return;
        }
        
        // Ajouter les nouvelles motorisations
        if (engines && engines.length > 0) {
            const enginesData = engines.map(engine => ({
                vehicle_id: parseInt(id),
                engine: engine.engine.trim(),
                fuel_type: engine.fuel_type
            }));
            
            const { error: insertError } = await supabase
                .from('engines')
                .insert(enginesData);
                
            if (insertError) {
                console.error('Engines insert error:', insertError);
                res.status(500).json({ error: 'Failed to create new engines' });
                return;
            }
        }
        
        res.json({ 
            success: true, 
            message: `Véhicule modifié avec ${engines?.length || 0} motorisation(s)`
        });
        
    } catch (error) {
        console.error('Unexpected error updating vehicle:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// DELETE /api/vehicles/:id - Supprimer un véhicule (cascade delete engines)
app.delete('/api/vehicles/:id', async (req, res) => {
    const { id } = req.params;
    
    try {
        console.log('Deleting vehicle:', id);
        
        const { error } = await supabase
            .from('vehicles')
            .delete()
            .eq('id', id);
            
        if (error) {
            console.error('Vehicle delete error:', error);
            res.status(500).json({ error: 'Failed to delete vehicle' });
            return;
        }
        
        console.log('Vehicle deleted:', id);
        res.json({ success: true, message: 'Véhicule supprimé avec succès' });
        
    } catch (error) {
        console.error('Unexpected error deleting vehicle:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// 🔧 Part Routes

// GET /api/admin/parts - Liste toutes les pièces avec compatibilités
app.get('/api/admin/parts', async (req, res) => {
    try {
        console.log('Fetching parts from Supabase...');
        
        const { data: parts, error } = await supabase
            .from('parts')
            .select(`
                id,
                name,
                sku,
                category,
                price,
                stock,
                description,
                image_url,
                part_vehicle_relations (
                    vehicle_id
                )
            `)
            .order('name', { ascending: true });
            
        if (error) {
            console.error('Supabase error:', error);
            res.status(500).json({ error: 'Failed to fetch parts from database' });
            return;
        }
        
        console.log(`Found ${parts.length} parts`);
        res.json(parts);
        
    } catch (error) {
        console.error('Error fetching parts:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// POST /api/parts - Créer une pièce avec compatibilités véhicules
app.post('/api/parts', async (req, res) => {
    const { name, sku, category, price, stock, description, image_url, vehicle_ids } = req.body;
    
    try {
        console.log('Creating part:', { name, sku, category, vehicle_ids: vehicle_ids?.length });
        
        // Validation
        if (!name || !sku || !category || price === undefined) {
            res.status(400).json({ 
                error: 'Missing required fields: name, sku, category, price' 
            });
            return;
        }
        
        // Créer la pièce
        const { data: part, error: partError } = await supabase
            .from('parts')
            .insert({ 
                name: name.trim(), 
                sku: sku.trim().toUpperCase(), 
                category: category.trim(), 
                price: parseFloat(price), 
                stock: stock || 0, 
                description: description?.trim() || null,
                image_url: image_url?.trim() || null
            })
            .select()
            .single();
            
        if (partError) {
            console.error('Part creation error:', partError);
            if (partError.code === '23505') { // Unique violation
                res.status(400).json({ error: 'SKU already exists' });
            } else {
                res.status(500).json({ error: 'Failed to create part' });
            }
            return;
        }
        
        console.log('Part created with ID:', part.id);
        
        // Créer les relations avec véhicules si spécifiées
        if (vehicle_ids && vehicle_ids.length > 0) {
            const relations = vehicle_ids.map(vehicle_id => ({
                part_id: part.id,
                vehicle_id: vehicle_id
            }));
            
            const { error: relationsError } = await supabase
                .from('part_vehicle_relations')
                .insert(relations);
                
            if (relationsError) {
                console.error('Relations creation error:', relationsError);
                // Tenter de supprimer la pièce créée
                await supabase.from('parts').delete().eq('id', part.id);
                res.status(500).json({ error: 'Failed to create vehicle relations' });
                return;
            }
            
            console.log(`Created ${vehicle_ids.length} vehicle relations for part ${part.id}`);
        }
        
        res.json({ 
            success: true, 
            part_id: part.id,
            vehicle_count: vehicle_ids ? vehicle_ids.length : 0,
            message: `Pièce créée et liée à ${vehicle_ids?.length || 0} véhicule(s)`
        });
        
    } catch (error) {
        console.error('Unexpected error creating part:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// PUT /api/parts/:id - Modifier une pièce et ses compatibilités
app.put('/api/parts/:id', async (req, res) => {
    const { id } = req.params;
    const { name, sku, category, price, stock, description, image_url, vehicle_ids } = req.body;
    
    try {
        console.log('Updating part:', id, { name, sku, category, vehicle_ids: vehicle_ids?.length });
        
        // Vérifier que la pièce existe
        const { data: existing, error: checkError } = await supabase
            .from('parts')
            .select('id')
            .eq('id', id)
            .single();
            
        if (checkError || !existing) {
            res.status(404).json({ error: 'Part not found' });
            return;
        }
        
        // Mettre à jour la pièce
        const { error: updateError } = await supabase
            .from('parts')
            .update({ 
                name: name?.trim(), 
                sku: sku?.trim().toUpperCase(), 
                category: category?.trim(), 
                price: price !== undefined ? parseFloat(price) : undefined,
                stock: stock !== undefined ? parseInt(stock) : undefined,
                description: description?.trim() || null,
                image_url: image_url?.trim() || null,
                updated_at: new Date().toISOString()
            })
            .eq('id', id);
            
        if (updateError) {
            console.error('Part update error:', updateError);
            if (updateError.code === '23505') {
                res.status(400).json({ error: 'SKU already exists' });
            } else {
                res.status(500).json({ error: 'Failed to update part' });
            }
            return;
        }
        
        // Supprimer les anciennes relations
        const { error: deleteError } = await supabase
            .from('part_vehicle_relations')
            .delete()
            .eq('part_id', id);
            
        if (deleteError) {
            console.error('Relations delete error:', deleteError);
            res.status(500).json({ error: 'Failed to update vehicle relations' });
            return;
        }
        
        // Ajouter les nouvelles relations
        if (vehicle_ids && vehicle_ids.length > 0) {
            const relations = vehicle_ids.map(vehicle_id => ({
                part_id: parseInt(id),
                vehicle_id: vehicle_id
            }));
            
            const { error: insertError } = await supabase
                .from('part_vehicle_relations')
                .insert(relations);
                
            if (insertError) {
                console.error('Relations insert error:', insertError);
                res.status(500).json({ error: 'Failed to create new vehicle relations' });
                return;
            }
        }
        
        res.json({ 
            success: true, 
            message: `Pièce modifiée avec ${vehicle_ids?.length || 0} compatibilité(s)`
        });
        
    } catch (error) {
        console.error('Unexpected error updating part:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// DELETE /api/parts/:id - Supprimer une pièce (cascade delete relations)
app.delete('/api/parts/:id', async (req, res) => {
    const { id } = req.params;
    
    try {
        console.log('Deleting part:', id);
        
        const { error } = await supabase
            .from('parts')
            .delete()
            .eq('id', id);
            
        if (error) {
            console.error('Part delete error:', error);
            res.status(500).json({ error: 'Failed to delete part' });
            return;
        }
        
        console.log('Part deleted:', id);
        res.json({ success: true, message: 'Pièce supprimée avec succès' });
        
    } catch (error) {
        console.error('Unexpected error deleting part:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// 🚀 Public Routes

// GET /api/categories - Liste des catégories disponibles
app.get('/api/categories', async (req, res) => {
    try {
        const { data, error } = await supabase
            .from('parts')
            .select('category')
            .order('category');
            
        if (error) {
            res.status(500).json({ error: 'Failed to fetch categories' });
            return;
        }
        
        // Extraire les catégories uniques
        const categories = [...new Set(data.map(item => item.category))];
        res.json(categories);
        
    } catch (error) {
        console.error('Error fetching categories:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// GET /api/brands - Liste des marques disponibles
app.get('/api/brands', async (req, res) => {
    try {
        const { data, error } = await supabase
            .from('vehicles')
            .select('brand')
            .order('brand');
            
        if (error) {
            res.status(500).json({ error: 'Failed to fetch brands' });
            return;
        }
        
        // Extraire les marques uniques
        const brands = [...new Set(data.map(item => item.brand))];
        res.json(brands);
        
    } catch (error) {
        console.error('Error fetching brands:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// 🛠️ Middleware 404
app.use('*', (req, res) => {
    res.status(404).json({ 
        error: 'Route not found',
        method: req.method,
        path: req.originalUrl 
    });
});

// 🛠️ Error Handler
app.use((error, req, res, next) => {
    console.error('Unhandled error:', error);
    res.status(500).json({ 
        error: 'Internal server error',
        message: 'Something went wrong'
    });
});

// 🚀 Start Server
app.listen(PORT, () => {
    console.log('🚗 GP Auto API Server - Supabase Edition');
    console.log(`📍 Server running on port ${PORT}`);
    console.log(`🗄️  Database: Supabase PostgreSQL`);
    console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`⏰ Started at: ${new Date().toISOString()}`);
    console.log('');
    console.log('🔗 API Endpoints:');
    console.log(`   GET  /api/health - Health check`);
    console.log(`   GET  /api/admin/vehicles - List vehicles`);
    console.log(`   POST /api/vehicles - Create vehicle`);
    console.log(`   GET  /api/admin/parts - List parts`);
    console.log(`   POST /api/parts - Create part`);
    console.log(`   GET  /api/categories - List categories`);
    console.log(`   GET  /api/brands - List brands`);
    console.log('');
    console.log('✅ Server ready to accept requests!');
});

module.exports = app;