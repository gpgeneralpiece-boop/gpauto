# GP AUTO Backend - Guide Complet

## 🎯 **Vue d'ensemble**

Backend Node.js/Express + SQLite pour le site e-commerce GP AUTO, spécialement optimisé pour le marché tunisien des pièces automobiles.

## 🚀 **Démarrage Ultra-Rapide**

### 1. Installation (30 secondes)
```bash
cd backend
chmod +x deploy.sh
./deploy.sh
```

### 2. Démarrage du serveur
```bash
npm start
# Serveur sur http://localhost:3001
```

### 3. Test immédiat
```bash
curl http://localhost:3001/api/health
```

## 📊 **APIs Disponibles**

### **Santé du Système**
```http
GET /api/health
```
Réponse:
```json
{
  "status": "OK",
  "message": "GP AUTO Backend fonctionne parfaitement",
  "timestamp": "2025-11-24T18:44:15.000Z"
}
```

### **Gestion des Véhicules**

#### 1. Liste des marques
```http
GET /api/vehicles
```
Réponse:
```json
[
  {"brand": "Citroën"},
  {"brand": "Dacia"},
  {"brand": "Hyundai"},
  {"brand": "Kia"},
  {"brand": "Peugeot"},
  {"brand": "Renault"},
  {"brand": "Volkswagen"}
]
```

#### 2. Modèles par marque
```http
GET /api/vehicles?brand=Renault
```
Réponse:
```json
[
  {"model": "Clio"},
  {"model": "Kangoo"},
  {"model": "Megane"},
  {"model": "Symbol"}
]
```

#### 3. Motorisations
```http
GET /api/vehicles/engines?brand=Renault&model=Clio
```
Réponse:
```json
[
  {"engine": "1.2L", "fuel_type": "Essence"}
]
```

### **Catalogue de Pièces**

#### 1. Pièces par véhicule
```http
GET /api/parts/vehicle/Renault/Clio/1.2L
```
Réponse:
```json
[
  {
    "id": 1,
    "name": "Plaquettes de frein avant",
    "sku": "PF-001",
    "category": "Freinage",
    "price": 107.97,
    "description": "Plaquettes de frein avant compatibles diverses marques",
    "stock": 25,
    "brand": "Textar",
    "vehicle_compatibility": "Universel",
    "oe_references": ["1609253180", "1609253980", "425086", "8K0698151A"],
    "image_url": "https://via.placeholder.com/300x200/1F4F5A/white?text=Plaquettes+Frein"
  }
]
```

#### 2. Pièces par catégorie
```http
GET /api/parts/category/Filtration
```

#### 3. Recherche multi-critères
```http
GET /api/search?query=frein
```
Recherche dans: nom, SKU, catégorie, marque, compatibilité, références OE

### **Gestion des Commandes**

#### 1. Créer une commande
```http
POST /api/orders
Content-Type: application/json

{
  "customer_name": "Ahmed Ben Ali",
  "phone": "+216 98 123 456",
  "address": "Avenue Habib Bourguiba, Tunis",
  "delivery_mode": "livraison",
  "items": [
    {
      "sku": "PF-001",
      "name": "Plaquettes de frein avant",
      "price": 107.97,
      "quantity": 1
    }
  ],
  "total_amount": 107.97,
  "delivery_fee": 0
}
```

#### 2. Obtenir une commande
```http
GET /api/orders/1
```

### **Statistiques**
```http
GET /api/stats
```
Réponse:
```json
{
  "total_parts": 10,
  "total_orders": 0,
  "total_brands": 7,
  "top_categories": [
    {"category": "Freinage", "count": 2},
    {"category": "Filtration", "count": 3}
  ]
}
```

## 🔧 **Intégration Frontend**

### **Exemple d'intégration dans votre site**

#### 1. Remplacer les données statiques par des APIs

**Avant (données statiques):**
```javascript
const vehicles = {
  "Renault": ["Clio", "Megane", "Symbol"]
};
```

**Après (API):**
```javascript
async function loadVehicles() {
  const response = await fetch('http://localhost:3001/api/vehicles');
  const vehicles = await response.json();
  
  const brandSelect = document.getElementById('brandSelect');
  vehicles.forEach(vehicle => {
    const option = document.createElement('option');
    option.value = vehicle.brand;
    option.textContent = vehicle.brand;
    brandSelect.appendChild(option);
  });
}
```

#### 2. Recherche en temps réel
```javascript
let searchTimeout;

function handleSearchInput(event) {
  clearTimeout(searchTimeout);
  const query = event.target.value;
  
  if (query.length < 2) return;
  
  searchTimeout = setTimeout(async () => {
    const response = await fetch(`http://localhost:3001/api/search?query=${encodeURIComponent(query)}`);
    const results = await response.json();
    displaySearchResults(results);
  }, 300);
}
```

#### 3. Création de commande
```javascript
async function createOrder(orderData) {
  try {
    const response = await fetch('http://localhost:3001/api/orders', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(orderData)
    });
    
    const result = await response.json();
    
    if (result.success) {
      showSuccessMessage(`Commande #${result.order_id} créée !`);
      clearCart();
    } else {
      showErrorMessage('Erreur lors de la création de la commande');
    }
  } catch (error) {
    console.error('Erreur:', error);
    showErrorMessage('Problème de connexion');
  }
}
```

## 🌍 **Déploiement**

### **Option 1: Vercel (Recommandée)**

1. Créez `vercel.json`:
```json
{
  "version": 2,
  "builds": [
    {
      "src": "server.js",
      "use": "@vercel/node"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "/server.js"
    }
  ]
}
```

2. Connectez sur vercel.com
3. Déploiement automatique

### **Option 2: Railway**

1. Créez un compte sur railway.app
2. Connectez votre repository GitHub
3. Déploiement automatique

### **Option 3: Heroku**

```bash
# Installation Heroku CLI requise
heroku create gp-auto-backend
git add .
git commit -m "Backend GP AUTO"
git push heroku main
```

## 💾 **Base de Données**

### **Tables créées automatiquement:**

1. **vehicles** - Véhicules tunisiens
2. **parts** - Catalogue de pièces avec références OE
3. **orders** - Commandes clients

### **Données pré-chargées:**

- **7 marques** populaires en Tunisie
- **15 modèles** avec motorisations
- **10 pièces** d'exemple avec prix TND
- **Références OE** complètes

## 🔐 **Sécurité**

- ✅ Validation des données
- ✅ CORS configuré
- ✅ Injection SQL protégée (SQLite paramétré)
- ✅ Gestion d'erreurs robuste

## 📈 **Optimisations**

- ✅ Index sur colonnes fréquentes
- ✅ Limite de résultats (50 max)
- ✅ Cache client recommandé
- ✅ Pagination future

## 🧪 **Tests**

### **Test complet:**
```bash
# Démarrage serveur
npm start &

# Tests API
curl http://localhost:3001/api/health
curl http://localhost:3001/api/vehicles
curl http://localhost:3001/api/search?query=frein
curl http://localhost:3001/api/stats

# Test POST
curl -X POST http://localhost:3001/api/orders \
  -H "Content-Type: application/json" \
  -d '{"customer_name":"Test","phone":"123","delivery_mode":"retrait","items":[],"total_amount":0}'
```

## 🚨 **Support et Debug**

### **Logs du serveur:**
```bash
npm start
# Console affiche tous les logs
```

### **Base de données:**
- Fichier: `backend/data/gpauto.db`
- Outil: SQLite Browser (sqlitebrowser.org)

### **Variables d'environnement:**
```bash
PORT=3001                    # Port du serveur
DATABASE_PATH=./data/gpauto.db  # Chemin DB
NODE_ENV=production          # Production/development
```

## ✨ **Fonctionnalités Avancées**

- 🔄 **Auto-reload** (dev): `npm run dev`
- 📊 **Statistiques** temps réel
- 🏷️ **Tags catégories** automatiques
- 🔍 **Recherche intelligente** avec ranking
- 💾 **Persistance** données commandes
- 📱 **API RESTful** complète

---

## 🎉 **Résultat Final**

Backend complet prêt en 30 secondes avec:
- ✅ 9 APIs fonctionnelles
- ✅ Base de données pré-remplie
- ✅ Données tunisiennes réalistes
- ✅ Déploiement simplifié
- ✅ Documentation complète

**Prochaine étape:** Connecter votre frontend aux APIs !