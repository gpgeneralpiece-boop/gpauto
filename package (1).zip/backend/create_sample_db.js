#!/usr/bin/env node

const sqlite3 = require('sqlite3').verbose();

// Base de données
const db = new sqlite3.Database('./data/gpauto.db');

console.log('🔧 Création de la base de données avec données d\'exemple...');

// Fonction pour attendre une requête
function runAsync(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function(err) {
            if (err) reject(err);
            else resolve(this);
        });
    });
}

// Créer les tables avec l'ancienne structure
async function createOldStructure() {
    // Table des véhicules (ancienne structure)
    await runAsync(`CREATE TABLE IF NOT EXISTS vehicles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        brand TEXT NOT NULL,
        model TEXT NOT NULL,
        year_from INTEGER,
        year_to INTEGER,
        engine TEXT,
        fuel_type TEXT
    )`);

    // Table des pièces (ancienne structure)
    await runAsync(`CREATE TABLE IF NOT EXISTS parts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        sku TEXT UNIQUE NOT NULL,
        category TEXT NOT NULL,
        price REAL NOT NULL,
        description TEXT,
        stock INTEGER DEFAULT 0,
        brand TEXT,
        vehicle_compatibility TEXT,
        oe_references TEXT,
        image_url TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Table des commandes
    await runAsync(`CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_name TEXT NOT NULL,
        phone TEXT NOT NULL,
        address TEXT NOT NULL,
        delivery_mode TEXT NOT NULL,
        items TEXT NOT NULL,
        total REAL NOT NULL,
        delivery_fee REAL DEFAULT 0,
        status TEXT DEFAULT 'En attente',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    console.log('📋 Tables créées avec succès !');
}

// Insérer des données d'exemple
async function insertSampleData() {
    // Véhicules d'exemple
    const vehicles = [
        { brand: 'Renault', model: 'Clio', year_from: 2019, year_to: 2023, engine: '1.2L', fuel_type: 'Essence' },
        { brand: 'Renault', model: 'Clio', year_from: 2019, year_to: 2023, engine: '1.5L dCi', fuel_type: 'Diesel' },
        { brand: 'Renault', model: 'Megane', year_from: 2016, year_to: 2022, engine: '1.6L', fuel_type: 'Essence' },
        { brand: 'Peugeot', model: '208', year_from: 2019, year_to: 2024, engine: '1.2L', fuel_type: 'Essence' },
        { brand: 'Peugeot', model: '208', year_from: 2019, year_to: 2024, engine: '1.5L', fuel_type: 'Diesel' },
        { brand: 'Citroën', model: 'C3', year_from: 2016, year_to: 2023, engine: '1.2L', fuel_type: 'Essence' },
        { brand: 'Dacia', model: 'Sandero', year_from: 2017, year_to: 2024, engine: '1.0L', fuel_type: 'Essence' },
        { brand: 'Dacia', model: 'Duster', year_from: 2018, year_to: 2024, engine: '1.5L dCi', fuel_type: 'Diesel' }
    ];

    for (const vehicle of vehicles) {
        await runAsync(
            `INSERT INTO vehicles (brand, model, year_from, year_to, engine, fuel_type) VALUES (?, ?, ?, ?, ?, ?)`,
            [vehicle.brand, vehicle.model, vehicle.year_from, vehicle.year_to, vehicle.engine, vehicle.fuel_type]
        );
    }

    // Pièces d'exemple
    const parts = [
        {
            name: 'Plaquettes de frein avant',
            sku: 'PFR-001',
            category: 'Freinage',
            price: 145.50,
            description: 'Plaquettes de frein haute qualité pour l\'avant',
            stock: 25,
            brand: 'Bosch',
            vehicle_compatibility: '["1","3","4"]',
            oe_references: '["425086", "425087", "7701209848", "425088"]',
            image_url: 'https://example.com/plaquettes-frein.jpg'
        },
        {
            name: 'Disque de frein avant',
            sku: 'DFR-001',
            category: 'Freinage',
            price: 285.00,
            description: 'Disque de frein ventilé 280mm',
            stock: 15,
            brand: 'TRW',
            vehicle_compatibility: '["1","2","3"]',
            oe_references: '["432061", "432062", "7701209849"]',
            image_url: 'https://example.com/disque-frein.jpg'
        },
        {
            name: 'Filtre à huile',
            sku: 'FO-001',
            category: 'Filtration',
            price: 35.75,
            description: 'Filtre à huile haute performance',
            stock: 40,
            brand: 'Mann-Filter',
            vehicle_compatibility: '["1","2","4","5","6","7","8"]',
            oe_references: '["7701209836", "7701209837", "1109AJ", "1109AK"]',
            image_url: 'https://example.com/filtre-huile.jpg'
        },
        {
            name: 'Filtre à air',
            sku: 'FA-001',
            category: 'Filtration',
            price: 42.30,
            description: 'Filtre à air original',
            stock: 30,
            brand: 'Mahle',
            vehicle_compatibility: '["1","2","4","5","6","7","8"]',
            oe_references: '["14401AA670", "14401AA671", "7701209838"]',
            image_url: 'https://example.com/filtre-air.jpg'
        },
        {
            name: 'Bougie d\'allumage',
            sku: 'BA-001',
            category: 'Allumage',
            price: 28.90,
            description: 'Bougie d\'allumage iridium',
            stock: 50,
            brand: 'NGK',
            vehicle_compatibility: '["1","4","5","6","7"]',
            oe_references: '["9091901234", "9091901235", "7701209839"]',
            image_url: 'https://example.com/bougie.jpg'
        },
        {
            name: 'Amortisseur avant',
            sku: 'AV-001',
            category: 'Suspension',
            price: 320.00,
            description: 'Amortisseur avant hydraulique',
            stock: 12,
            brand: 'Monroe',
            vehicle_compatibility: '["3","4","6"]',
            oe_references: '["7701209840", "7701209841"]',
            image_url: 'https://example.com/amortisseur.jpg'
        },
        {
            name: 'Pneumatic 185/65R15',
            sku: 'PN-001',
            category: 'Pneumatiques',
            price: 120.00,
            description: 'Pneumatic été 185/65R15',
            stock: 8,
            brand: 'Michelin',
            vehicle_compatibility: '["1","4","5","7"]',
            oe_references: '[]',
            image_url: 'https://example.com/pneumatic.jpg'
        },
        {
            name: 'Plaquettes arrière',
            sku: 'PAR-001',
            category: 'Freinage',
            price: 125.00,
            description: 'Plaquettes de frein arrière',
            stock: 20,
            brand: 'Bosch',
            vehicle_compatibility: '["1","3","4"]',
            oe_references: '["425086R", "425087R"]',
            image_url: 'https://example.com/plaquettes-arriere.jpg'
        },
        {
            name: 'Filtre carburant',
            sku: 'FC-001',
            category: 'Filtration',
            price: 55.50,
            description: 'Filtre carburant haute efficacité',
            stock: 35,
            brand: 'Mann-Filter',
            vehicle_compatibility: '["2","3","5","6","8"]',
            oe_references: '["7701209842", "16400Z5019"]',
            image_url: 'https://example.com/filtre-carburant.jpg'
        },
        {
            name: 'Batterie 12V 60Ah',
            sku: 'BT-001',
            category: 'Électrique',
            price: 420.00,
            description: 'Batterie voiture 12V 60Ah sans entretien',
            stock: 6,
            brand: 'Varta',
            vehicle_compatibility: '["1","2","3","4","5","6","7","8"]',
            oe_references: '[]',
            image_url: 'https://example.com/batterie.jpg'
        }
    ];

    for (const part of parts) {
        await runAsync(
            `INSERT INTO parts (name, sku, category, price, description, stock, brand, vehicle_compatibility, oe_references, image_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [part.name, part.sku, part.category, part.price, part.description, part.stock, part.brand, part.vehicle_compatibility, part.oe_references, part.image_url]
        );
    }

    console.log('✅ Données d\'exemple insérées !');
}

// Exécuter
async function main() {
    try {
        await createOldStructure();
        await insertSampleData();
        console.log('\n🎉 Base de données créée avec succès !');
        console.log('📊 Contenu: 8 véhicules, 10 pièces avec compatibilités');
    } catch (error) {
        console.error('❌ Erreur:', error);
    } finally {
        db.close();
    }
}

main();