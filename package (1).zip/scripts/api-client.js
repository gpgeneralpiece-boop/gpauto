// scripts/api-client.js - Client API pour GP AUTO
// Utilise les endpoints Vercel + Supabase

class GP.AutoAPI {
    constructor() {
        // Auto-détection de l'URL de base
        this.baseURL = this.detectBaseURL();
    }
    
    // Détection automatique de l'URL selon l'environnement
    detectBaseURL() {
        if (typeof window !== 'undefined') {
            // Environment navigateur
            if (window.location.hostname === 'localhost') {
                return 'http://localhost:3000/api';
            } else {
                // Production Vercel
                return `${window.location.origin}/api`;
            }
        } else {
            // Environment Node.js
            return process.env.API_BASE_URL || 'http://localhost:3000/api';
        }
    }
    
    // Méthode générique pour les requêtes
    async request(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            }
        };
        
        const finalOptions = { ...defaultOptions, ...options };
        
        console.log(`🌐 API Request: ${finalOptions.method || 'GET'} ${url}`);
        
        try {
            const response = await fetch(url, finalOptions);
            
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                const errorMessage = errorData.error || `HTTP ${response.status}: ${response.statusText}`;
                throw new Error(errorMessage);
            }
            
            const data = await response.json();
            console.log(`✅ API Success: ${endpoint}`, data);
            return data;
            
        } catch (error) {
            console.error(`❌ API Error: ${endpoint}`, error);
            throw error;
        }
    }
    
    // 🏥 Health Check
    async health() {
        return this.request('/health');
    }
    
    // 🚗 Véhicules
    async getVehicles() {
        return this.request('/admin/vehicles');
    }
    
    async createVehicle(vehicleData) {
        return this.request('/vehicles', {
            method: 'POST',
            body: JSON.stringify(vehicleData)
        });
    }
    
    async updateVehicle(id, vehicleData) {
        return this.request(`/vehicles/${id}`, {
            method: 'PUT',
            body: JSON.stringify(vehicleData)
        });
    }
    
    async deleteVehicle(id) {
        return this.request(`/vehicles/${id}`, {
            method: 'DELETE'
        });
    }
    
    // 🔧 Pièces
    async getParts() {
        return this.request('/admin/parts');
    }
    
    async createPart(partData) {
        return this.request('/parts', {
            method: 'POST',
            body: JSON.stringify(partData)
        });
    }
    
    async updatePart(id, partData) {
        return this.request(`/parts/${id}`, {
            method: 'PUT',
            body: JSON.stringify(partData)
        });
    }
    
    async deletePart(id) {
        return this.request(`/parts/${id}`, {
            method: 'DELETE'
        });
    }
    
    // 📊 Données publiques
    async getCategories() {
        return this.request('/categories');
    }
    
    async getBrands() {
        return this.request('/brands');
    }
    
    // 🔍 Utilitaires
    async testConnection() {
        try {
            const health = await this.health();
            return {
                connected: true,
                message: health.message,
                database: health.database,
                timestamp: health.timestamp
            };
        } catch (error) {
            return {
                connected: false,
                error: error.message
            };
        }
    }
    
    // 📝 Logging des appels API
    logAPIUsage(method, endpoint, success = true) {
        const timestamp = new Date().toISOString();
        const status = success ? '✅' : '❌';
        console.log(`${status} [${timestamp}] ${method} ${endpoint}`);
        
        // Stockage local pour debug
        if (typeof localStorage !== 'undefined') {
            const logs = JSON.parse(localStorage.getItem('api_logs') || '[]');
            logs.push({
                timestamp,
                method,
                endpoint,
                success,
                url: this.baseURL + endpoint
            });
            
            // Garder seulement les 100 derniers logs
            if (logs.length > 100) {
                logs.splice(0, logs.length - 100);
            }
            
            localStorage.setItem('api_logs', JSON.stringify(logs));
        }
    }
    
    // 📈 Statistiques d'utilisation
    getUsageStats() {
        if (typeof localStorage === 'undefined') {
            return null;
        }
        
        const logs = JSON.parse(localStorage.getItem('api_logs') || '[]');
        
        return {
            total_calls: logs.length,
            successful_calls: logs.filter(log => log.success).length,
            failed_calls: logs.filter(log => !log.success).length,
            success_rate: logs.length > 0 
                ? Math.round((logs.filter(log => log.success).length / logs.length) * 100)
                : 0,
            last_calls: logs.slice(-5) // 5 derniers appels
        };
    }
    
    // 🧹 Nettoyer les logs
    clearLogs() {
        if (typeof localStorage !== 'undefined') {
            localStorage.removeItem('api_logs');
            console.log('📝 API logs cleared');
        }
    }
}

// 🎯 Instance globale unique
GP.AutoAPI = new GP.AutoAPI();

// 🔧 Fonctions de débogage globales
if (typeof window !== 'undefined') {
    // Exposer des fonctions globales pour debug
    window.GP_API_TEST = () => {
        GP.AutoAPI.testConnection().then(result => {
            console.log('🔍 API Test Result:', result);
            alert(`API Connection: ${result.connected ? '✅ OK' : '❌ Failed'}\n${result.message || result.error}`);
        });
    };
    
    window.GP_API_STATS = () => {
        const stats = GP.AutoAPI.getUsageStats();
        console.log('📊 API Usage Stats:', stats);
        if (stats) {
            alert(`API Statistics:
Total Calls: ${stats.total_calls}
Success Rate: ${stats.success_rate}%
Successful: ${stats.successful_calls}
Failed: ${stats.failed_calls}`);
        }
    };
    
    window.GP_API_LOGS = () => {
        const logs = JSON.parse(localStorage.getItem('api_logs') || '[]');
        console.table(logs);
    };
    
    console.log(`
🚗 GP AUTO API Client Loaded
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Base URL: ${GP.AutoAPI.baseURL}
Functions available:
  - GP.AutoAPI.health()
  - GP.AutoAPI.getVehicles()
  - GP.AutoAPI.createVehicle(data)
  - GP.AutoAPI.getParts()
  - GP.AutoAPI.createPart(data)
  
Debug functions:
  - GP_API_TEST()     // Test connection
  - GP_API_STATS()    // Usage statistics  
  - GP_API_LOGS()     // View logs
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    `);
}

// 📤 Export pour modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = GP.AutoAPI;
}