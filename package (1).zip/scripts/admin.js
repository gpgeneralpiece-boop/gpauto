// GP AUTO - Panel Administration JavaScript

// Configuration
const API_BASE_URL = window.location.origin.includes('localhost') 
    ? 'http://localhost:3001' 
    : '/api';

// Variables globales
let currentTab = 'dashboard';
let vehicles = [];
let parts = [];
let orders = [];
let stats = {};

// ================================
// INITIALISATION
// ================================

document.addEventListener('DOMContentLoaded', function() {
    initializeAdmin();
});

async function initializeAdmin() {
    try {
        // Vérifier la connexion au backend
        await checkBackendConnection();
        
        // Charger les données
        await loadStats();
        await loadVehicles();
        await loadParts();
        await loadOrders();
        
        // Configurer les filtres
        setupFilters();
        
        console.log('✅ Panel Admin initialisé');
    } catch (error) {
        console.error('❌ Erreur initialisation admin:', error);
        showToast('Erreur de connexion au backend', 'error');
    }
}

// ================================
// GESTION DES ONGLETS
// ================================

function switchTab(tabName) {
    // Masquer tous les onglets
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Désactiver tous les boutons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Afficher l'onglet sélectionné
    document.getElementById(tabName).classList.add('active');
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    
    currentTab = tabName;
    
    // Actions spécifiques par onglet
    switch(tabName) {
        case 'dashboard':
            refreshStats();
            loadRecentOrders();
            break;
        case 'vehicles':
            refreshVehiclesTable();
            break;
        case 'parts':
            refreshPartsTable();
            break;
        case 'orders':
            refreshOrdersTable();
            break;
    }
}

// ================================
// GESTION DU DASHBOARD
// ================================

async function loadStats() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/stats`);
        if (!response.ok) throw new Error('Erreur API stats');
        
        const data = await response.json();
        stats = data;
        
        // Mettre à jour les cards
        document.getElementById('totalVehicles').textContent = data.total_brands || 0;
        document.getElementById('totalParts').textContent = data.total_parts || 0;
        document.getElementById('totalOrders').textContent = data.total_orders || 0;
        document.getElementById('totalRevenue').textContent = '0.00'; // À calculer
        
    } catch (error) {
        console.error('Erreur chargement stats:', error);
        // Valeurs par défaut
        document.getElementById('totalVehicles').textContent = '0';
        document.getElementById('totalParts').textContent = '0';
        document.getElementById('totalOrders').textContent = '0';
        document.getElementById('totalRevenue').textContent = '0.00';
    }
}

function refreshStats() {
    showToast('Actualisation des statistiques...', 'info');
    loadStats().then(() => {
        showToast('Statistiques actualisées', 'success');
    }).catch(() => {
        showToast('Erreur lors de l\'actualisation', 'error');
    });
}

async function loadRecentOrders() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/orders`);
        if (!response.ok) throw new Error('Erreur API orders');
        
        const allOrders = await response.json();
        
        // Prendre les 5 dernières commandes
        const recentOrders = allOrders
            .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
            .slice(0, 5);
        
        displayRecentOrders(recentOrders);
    } catch (error) {
        console.error('Erreur chargement commandes récentes:', error);
        document.getElementById('recentOrders').innerHTML = '<p class="no-data">Erreur de chargement</p>';
    }
}

function displayRecentOrders(orders) {
    const container = document.getElementById('recentOrders');
    
    if (orders.length === 0) {
        container.innerHTML = '<p class="no-data">Aucune commande récente</p>';
        return;
    }
    
    container.innerHTML = orders.map(order => `
        <div class="recent-item" onclick="showOrderDetails(${order.id})">
            <div>
                <strong>Commande #${order.id}</strong>
                <p>${order.customer_name} - ${order.phone}</p>
                <small>${formatDate(order.created_at)}</small>
            </div>
            <div class="text-right">
                <strong>${order.total_amount.toFixed(2)} TND</strong>
                <span class="status-badge status-${order.status}">${getStatusText(order.status)}</span>
            </div>
        </div>
    `).join('');
}

// ================================
// GESTION DES VÉHICULES
// ================================

async function loadVehicles() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/admin/vehicles`);
        if (!response.ok) throw new Error('Erreur API admin vehicles');
        
        vehicles = await response.json();
        
        // Mettre à jour les filtres
        updateVehicleFilters();
        
        // Charger les marques pour le formulaire
        loadBrandsForForm();
        
    } catch (error) {
        console.error('Erreur chargement véhicules:', error);
        vehicles = [];
    }
}

function updateVehicleFilters() {
    const brandSelect = document.getElementById('brandFilter');
    const brands = [...new Set(vehicles.map(v => v.brand))].sort();
    
    brandSelect.innerHTML = '<option value="">Toutes les marques</option>';
    brands.forEach(brand => {
        const option = document.createElement('option');
        option.value = brand;
        option.textContent = brand;
        brandSelect.appendChild(option);
    });
}

function refreshVehiclesTable() {
    displayVehiclesTable(vehicles);
}

function displayVehiclesTable(data) {
    const tbody = document.getElementById('vehiclesTableBody');
    
    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="no-data">Aucun véhicule trouvé</td></tr>';
        return;
    }
    
    tbody.innerHTML = data.map(vehicle => {
        const enginesText = vehicle.engines.length > 0 ? 
            vehicle.engines.map(e => `${e.engine} ${e.fuel_type}`).join(', ') : 
            'Aucune';
        
        return `
        <tr>
            <td>${vehicle.id}</td>
            <td>${vehicle.brand}</td>
            <td>${vehicle.model}</td>
            <td>${vehicle.year_from || '-'} ${vehicle.year_to ? `à ${vehicle.year_to}` : ''}</td>
            <td>${enginesText}</td>
            <td>
                <button class="action-btn edit" onclick="editVehicle(${JSON.stringify(vehicle).replace(/"/g, '&quot;')})" title="Modifier">
                    ✏️
                </button>
                <button class="action-btn delete" onclick="deleteVehicle(${vehicle.id})" title="Supprimer">
                    🗑️
                </button>
            </td>
        </tr>
    `;
    }).join('');
}

function filterVehicles() {
    const searchTerm = document.getElementById('vehicleSearch').value.toLowerCase();
    const selectedBrand = document.getElementById('brandFilter').value;
    
    let filtered = vehicles;
    
    // Filtrer par texte de recherche
    if (searchTerm) {
        filtered = filtered.filter(vehicle => 
            vehicle.brand.toLowerCase().includes(searchTerm) ||
            vehicle.model.toLowerCase().includes(searchTerm)
        );
    }
    
    // Filtrer par marque
    if (selectedBrand) {
        filtered = filtered.filter(vehicle => vehicle.brand === selectedBrand);
    }
    
    displayVehiclesTable(filtered);
}

// CRUD Véhicules
function addVehicle() {
    document.getElementById('vehicleModalTitle').textContent = 'Nouveau Véhicule';
    document.getElementById('vehicleForm').reset();
    document.getElementById('vehicleId').value = '';
    
    // Réinitialiser les sélecteurs
    document.getElementById('vehicleBrand').style.display = 'block';
    document.getElementById('vehicleBrandNew').style.display = 'none';
    document.getElementById('vehicleModel').style.display = 'block';
    document.getElementById('vehicleModelNew').style.display = 'none';
    
    // Réinitialiser les valeurs
    document.getElementById('vehicleBrandNew').required = false;
    document.getElementById('vehicleModelNew').required = false;
    
    // Vider le container de motorisations et ajouter un champ par défaut
    document.getElementById('enginesContainer').innerHTML = '';
    initializeVehicleForm();
    
    showModal('vehicleModal');
}

function editVehicle(vehicle) {
    document.getElementById('vehicleModalTitle').textContent = 'Modifier Véhicule';
    document.getElementById('vehicleId').value = vehicle.id || '';
    document.getElementById('vehicleBrand').value = vehicle.brand || '';
    document.getElementById('vehicleModel').value = vehicle.model || '';
    document.getElementById('vehicleYearFrom').value = vehicle.year_from || '';
    document.getElementById('vehicleYearTo').value = vehicle.year_to || '';
    document.getElementById('vehicleEngine').value = vehicle.engine || '';
    document.getElementById('vehicleFuelType').value = vehicle.fuel_type || '';
    showModal('vehicleModal');
}

async function saveVehicle() {
    const form = document.getElementById('vehicleForm');
    const formData = {
        brand: document.getElementById('vehicleBrand').value.trim(),
        model: document.getElementById('vehicleModel').value.trim(),
        year_from: document.getElementById('vehicleYearFrom').value ? parseInt(document.getElementById('vehicleYearFrom').value) : null,
        year_to: document.getElementById('vehicleYearTo').value ? parseInt(document.getElementById('vehicleYearTo').value) : null,
        engine: document.getElementById('vehicleEngine').value.trim(),
        fuel_type: document.getElementById('vehicleFuelType').value
    };
    
    // Validation
    if (!formData.brand || !formData.model || !formData.engine || !formData.fuel_type) {
        showToast('Veuillez remplir tous les champs obligatoires', 'error');
        return;
    }
    
    try {
        const vehicleId = document.getElementById('vehicleId').value;
        const url = vehicleId ? `${API_BASE_URL}/api/vehicles/${vehicleId}` : `${API_BASE_URL}/api/vehicles`;
        const method = vehicleId ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        if (!response.ok) throw new Error('Erreur sauvegarde véhicule');
        
        showToast('Véhicule sauvegardé avec succès', 'success');
        closeModal('vehicleModal');
        loadVehicles(); // Recharger
        
    } catch (error) {
        console.error('Erreur sauvegarde véhicule:', error);
        showToast('Erreur lors de la sauvegarde', 'error');
    }
}

async function deleteVehicle(id) {
    if (!id || !confirm('Êtes-vous sûr de vouloir supprimer ce véhicule ?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/vehicles/${id}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) throw new Error('Erreur suppression véhicule');
        
        showToast('Véhicule supprimé avec succès', 'success');
        loadVehicles(); // Recharger
        
    } catch (error) {
        console.error('Erreur suppression véhicule:', error);
        showToast('Erreur lors de la suppression', 'error');
    }
}

// ================================
// GESTION DES PIÈCES
// ================================

async function loadParts() {
    try {
        // Charger toutes les catégories d'abord pour les filtres
        const categoriesResponse = await fetch(`${API_BASE_URL}/api/categories`);
        const categories = categoriesResponse.ok ? await categoriesResponse.json() : [];
        
        // Charger les pièces par catégorie
        const allParts = [];
        for (const category of categories) {
            const response = await fetch(`${API_BASE_URL}/api/parts/category/${category.category}`);
            if (response.ok) {
                const parts = await response.json();
                allParts.push(...parts);
            }
        }
        
        parts = allParts;
        
        // Mettre à jour les filtres
        updatePartFilters();
        
    } catch (error) {
        console.error('Erreur chargement pièces:', error);
        parts = [];
    }
}

function updatePartFilters() {
    const categorySelect = document.getElementById('categoryFilter');
    const categories = [...new Set(parts.map(p => p.category))].sort();
    
    categorySelect.innerHTML = '<option value="">Toutes les catégories</option>';
    categories.forEach(category => {
        const option = document.createElement('option');
        option.value = category;
        option.textContent = category;
        categorySelect.appendChild(option);
    });
}

function refreshPartsTable() {
    displayPartsTable(parts);
}

function displayPartsTable(data) {
    const tbody = document.getElementById('partsTableBody');
    
    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="no-data">Aucune pièce trouvée</td></tr>';
        return;
    }
    
    tbody.innerHTML = data.map(part => `
        <tr>
            <td>
                <img src="${part.image_url || 'https://via.placeholder.com/50'}" 
                     alt="${part.name}" class="part-image">
            </td>
            <td><strong>${part.sku}</strong></td>
            <td>
                <div>
                    <strong>${part.name}</strong>
                    <br>
                    <small class="text-secondary">${part.description || ''}</small>
                </div>
            </td>
            <td>${part.category}</td>
            <td><strong>${part.price.toFixed(2)} TND</strong></td>
            <td>
                <span class="stock-indicator ${getStockClass(part.stock)}">
                    ${part.stock} unités
                </span>
            </td>
            <td>${part.brand || '-'}</td>
            <td>
                <button class="action-btn edit" onclick="editPart(${JSON.stringify(part).replace(/"/g, '&quot;')})" title="Modifier">
                    ✏️
                </button>
                <button class="action-btn delete" onclick="deletePart('${part.sku}')" title="Supprimer">
                    🗑️
                </button>
            </td>
        </tr>
    `).join('');
}

function getStockClass(stock) {
    if (stock <= 0) return 'stock-out';
    if (stock <= 5) return 'stock-low';
    return 'stock-in';
}

function filterParts() {
    const searchTerm = document.getElementById('partSearch').value.toLowerCase();
    const selectedCategory = document.getElementById('categoryFilter').value;
    const stockFilter = document.getElementById('stockFilter').value;
    
    let filtered = parts;
    
    // Filtrer par texte de recherche
    if (searchTerm) {
        filtered = filtered.filter(part => 
            part.name.toLowerCase().includes(searchTerm) ||
            part.sku.toLowerCase().includes(searchTerm) ||
            (part.oe_references && part.oe_references.some(ref => 
                ref.toLowerCase().includes(searchTerm)
            ))
        );
    }
    
    // Filtrer par catégorie
    if (selectedCategory) {
        filtered = filtered.filter(part => part.category === selectedCategory);
    }
    
    // Filtrer par stock
    if (stockFilter) {
        filtered = filtered.filter(part => {
            switch(stockFilter) {
                case 'in-stock': return part.stock > 5;
                case 'low-stock': return part.stock > 0 && part.stock <= 5;
                case 'out-of-stock': return part.stock <= 0;
                default: return true;
            }
        });
    }
    
    displayPartsTable(filtered);
}

// CRUD Pièces
function addPart() {
    document.getElementById('partModalTitle').textContent = 'Nouvelle Pièce';
    document.getElementById('partForm').reset();
    document.getElementById('partId').value = '';
    showModal('partModal');
}

function editPart(part) {
    document.getElementById('partModalTitle').textContent = 'Modifier Pièce';
    document.getElementById('partId').value = part.id || '';
    document.getElementById('partName').value = part.name || '';
    document.getElementById('partSku').value = part.sku || '';
    document.getElementById('partCategory').value = part.category || '';
    document.getElementById('partPrice').value = part.price || '';
    document.getElementById('partStock').value = part.stock || '';
    document.getElementById('partBrand').value = part.brand || '';
    document.getElementById('partImageUrl').value = part.image_url || '';
    document.getElementById('partDescription').value = part.description || '';
    document.getElementById('partCompatibility').value = part.vehicle_compatibility || '';
    document.getElementById('partOeReferences').value = part.oe_references ? part.oe_references.join(', ') : '';
    showModal('partModal');
}

async function savePart() {
    const formData = {
        name: document.getElementById('partName').value.trim(),
        sku: document.getElementById('partSku').value.trim(),
        category: document.getElementById('partCategory').value,
        price: parseFloat(document.getElementById('partPrice').value),
        stock: parseInt(document.getElementById('partStock').value),
        brand: document.getElementById('partBrand').value.trim(),
        image_url: document.getElementById('partImageUrl').value.trim(),
        description: document.getElementById('partDescription').value.trim(),
        vehicle_compatibility: document.getElementById('partCompatibility').value.trim(),
        oe_references: document.getElementById('partOeReferences').value
            .split(',')
            .map(ref => ref.trim())
            .filter(ref => ref.length > 0)
    };
    
    // Validation
    if (!formData.name || !formData.sku || !formData.category || 
        isNaN(formData.price) || isNaN(formData.stock)) {
        showToast('Veuillez remplir tous les champs obligatoires', 'error');
        return;
    }
    
    try {
        const partId = document.getElementById('partId').value;
        const url = partId ? `${API_BASE_URL}/api/parts/${partId}` : `${API_BASE_URL}/api/parts`;
        const method = partId ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        if (!response.ok) throw new Error('Erreur sauvegarde pièce');
        
        showToast('Pièce sauvegardée avec succès', 'success');
        closeModal('partModal');
        loadParts(); // Recharger
        
    } catch (error) {
        console.error('Erreur sauvegarde pièce:', error);
        showToast('Erreur lors de la sauvegarde', 'error');
    }
}

async function deletePart(sku) {
    if (!sku || !confirm('Êtes-vous sûr de vouloir supprimer cette pièce ?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/parts/${sku}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) throw new Error('Erreur suppression pièce');
        
        showToast('Pièce supprimée avec succès', 'success');
        loadParts(); // Recharger
        
    } catch (error) {
        console.error('Erreur suppression pièce:', error);
        showToast('Erreur lors de la suppression', 'error');
    }
}

// ================================
// GESTION DES COMMANDES
// ================================

async function loadOrders() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/orders`);
        if (!response.ok) throw new Error('Erreur API orders');
        
        orders = await response.json();
        
    } catch (error) {
        console.error('Erreur chargement commandes:', error);
        orders = [];
    }
}

function refreshOrdersTable() {
    displayOrdersTable(orders);
}

function displayOrdersTable(data) {
    const tbody = document.getElementById('ordersTableBody');
    
    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="no-data">Aucune commande trouvée</td></tr>';
        return;
    }
    
    tbody.innerHTML = data.map(order => `
        <tr>
            <td><strong>#${order.id}</strong></td>
            <td>${order.customer_name}</td>
            <td>${order.phone}</td>
            <td>${formatDate(order.created_at)}</td>
            <td><strong>${order.total_amount.toFixed(2)} TND</strong></td>
            <td>
                ${order.delivery_mode === 'livraison' ? '🚚 Livraison' : '🏪 Retrait'}
                <br>
                <small>${order.delivery_fee > 0 ? `+${order.delivery_fee.toFixed(2)} TND` : 'Gratuit'}</small>
            </td>
            <td>
                <span class="status-badge status-${order.status}">
                    ${getStatusText(order.status)}
                </span>
            </td>
            <td>
                <button class="action-btn edit" onclick="showOrderDetails(${order.id})" title="Voir détails">
                    👁️
                </button>
            </td>
        </tr>
    `).join('');
}

function filterOrders() {
    const statusFilter = document.getElementById('statusFilter').value;
    const dateFilter = document.getElementById('dateFilter').value;
    
    let filtered = orders;
    
    // Filtrer par statut
    if (statusFilter) {
        filtered = filtered.filter(order => order.status === statusFilter);
    }
    
    // Filtrer par date
    if (dateFilter) {
        const filterDate = new Date(dateFilter).toDateString();
        filtered = filtered.filter(order => 
            new Date(order.created_at).toDateString() === filterDate
        );
    }
    
    displayOrdersTable(filtered);
}

async function showOrderDetails(orderId) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/orders/${orderId}`);
        if (!response.ok) throw new Error('Erreur API order details');
        
        const order = await response.json();
        
        document.getElementById('orderModalId').textContent = order.id;
        document.getElementById('orderDetails').innerHTML = `
            <div class="order-detail-section">
                <h4>Informations Client</h4>
                <p><strong>Nom:</strong> ${order.customer_name}</p>
                <p><strong>Téléphone:</strong> ${order.phone}</p>
                <p><strong>Adresse:</strong> ${order.address || 'Non renseignée'}</p>
                <p><strong>Mode de livraison:</strong> ${order.delivery_mode === 'livraison' ? 'Livraison à domicile' : 'Retrait au comptoir'}</p>
            </div>
            
            <div class="order-detail-section">
                <h4>Articles Commandés</h4>
                <table class="order-items-table">
                    <thead>
                        <tr>
                            <th>SKU</th>
                            <th>Nom</th>
                            <th>Quantité</th>
                            <th>Prix unitaire</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${order.items.map(item => `
                            <tr>
                                <td>${item.sku}</td>
                                <td>${item.name}</td>
                                <td>${item.quantity}</td>
                                <td>${item.price.toFixed(2)} TND</td>
                                <td><strong>${(item.price * item.quantity).toFixed(2)} TND</strong></td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
            
            <div class="order-detail-section">
                <h4>Totaux</h4>
                <div class="order-totals">
                    <p><strong>Sous-total:</strong> ${(order.total_amount - order.delivery_fee).toFixed(2)} TND</p>
                    <p><strong>Frais de livraison:</strong> ${order.delivery_fee > 0 ? order.delivery_fee.toFixed(2) + ' TND' : 'Gratuit'}</p>
                    <p class="order-total"><strong>Total:</strong> ${order.total_amount.toFixed(2)} TND</p>
                </div>
            </div>
            
            <div class="order-detail-section">
                <p><strong>Date de commande:</strong> ${formatDateTime(order.created_at)}</p>
                <p><strong>Statut actuel:</strong> <span class="status-badge status-${order.status}">${getStatusText(order.status)}</span></p>
            </div>
        `;
        
        showModal('orderModal');
        
    } catch (error) {
        console.error('Erreur chargement détails commande:', error);
        showToast('Erreur lors du chargement des détails', 'error');
    }
}

async function updateOrderStatus(orderId, newStatus) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/orders/${orderId}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ status: newStatus })
        });
        
        if (!response.ok) throw new Error('Erreur mise à jour statut');
        
        showToast(`Statut mis à jour: ${getStatusText(newStatus)}`, 'success');
        closeModal('orderModal');
        loadOrders(); // Recharger
        loadStats(); // Actualiser stats
        
    } catch (error) {
        console.error('Erreur mise à jour statut:', error);
        showToast('Erreur lors de la mise à jour du statut', 'error');
    }
}

// ================================
// GESTION DES CONFIGURATIONS
// ================================

function setupFilters() {
    // Configurer les filtres existants
    filterVehicles();
    filterParts();
    filterOrders();
}

function saveDeliverySettings() {
    const threshold = parseFloat(document.getElementById('freeDeliveryThreshold').value);
    const fee = parseFloat(document.getElementById('deliveryFee').value);
    
    // Sauvegarder en localStorage pour l'instant
    localStorage.setItem('delivery_config', JSON.stringify({
        threshold,
        fee
    }));
    
    showToast('Configuration de livraison sauvegardée', 'success');
}

function saveSiteSettings() {
    const settings = {
        name: document.getElementById('siteName').value,
        phone: document.getElementById('sitePhone').value,
        email: document.getElementById('siteEmail').value
    };
    
    // Sauvegarder en localStorage pour l'instant
    localStorage.setItem('site_config', JSON.stringify(settings));
    
    showToast('Configuration du site sauvegardée', 'success');
}

function clearCache() {
    localStorage.clear();
    showToast('Cache vidé avec succès', 'success');
}

function resetDatabase() {
    if (!confirm('Êtes-vous sûr de vouloir réinitialiser la base de données ? Toutes les données seront perdues.')) {
        return;
    }
    
    showToast('Réinitialisation en cours...', 'warning');
    
    // Simuler la réinitialisation
    setTimeout(() => {
        localStorage.clear();
        location.reload();
    }, 2000);
}

// ================================
// UTILITAIRES
// ================================

async function checkBackendConnection() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/health`);
        if (!response.ok) throw new Error('Backend non accessible');
        
        const health = await response.json();
        console.log('✅ Backend connecté:', health.message);
        
    } catch (error) {
        console.error('❌ Backend non accessible:', error);
        throw new Error('Backend non accessible');
    }
}

function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toastMessage');
    
    toast.className = `toast ${type}`;
    toastMessage.textContent = message;
    toast.style.display = 'block';
    
    setTimeout(() => {
        hideToast();
    }, 4000);
}

function hideToast() {
    document.getElementById('toast').style.display = 'none';
}

function showModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('fr-FR');
}

function formatDateTime(dateString) {
    return new Date(dateString).toLocaleString('fr-FR');
}

function getStatusText(status) {
    const statusMap = {
        'pending': 'En attente',
        'processing': 'En traitement',
        'shipped': 'Expédié',
        'delivered': 'Livré',
        'cancelled': 'Annulé'
    };
    return statusMap[status] || status;
}

function logout() {
    if (confirm('Êtes-vous sûr de vouloir vous déconnecter ?')) {
        // Réinitialiser les données en mémoire
        vehicles = [];
        parts = [];
        orders = [];
        stats = {};
        
        showToast('Déconnexion réussie', 'success');
        
        // Rediriger vers la page principale
        setTimeout(() => {
            window.location.href = '/';
        }, 1000);
    }
}

// ================================
// ACTIONS RAPIDES
// ================================

function viewAllOrders() {
    switchTab('orders');
}

function exportData() {
    const data = {
        vehicles,
        parts,
        orders,
        stats,
        exportDate: new Date().toISOString()
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(dataBlob);
    link.download = `gp-auto-export-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    
    showToast('Données exportées avec succès', 'success');
}

function exportOrders() {
    const ordersData = orders.map(order => ({
        id: order.id,
        customer_name: order.customer_name,
        phone: order.phone,
        created_at: order.created_at,
        total_amount: order.total_amount,
        delivery_fee: order.delivery_fee,
        status: order.status,
        items_count: order.items ? order.items.length : 0
    }));
    
    const csvContent = [
        'ID,Client,Téléphone,Date,Total TND,Livraison TND,Statut,Nb Articles',
        ...ordersData.map(order => 
            `${order.id},"${order.customer_name}",${order.phone},${order.created_at},${order.total_amount},${order.delivery_fee},${order.status},${order.items_count}`
        )
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `gp-auto-commandes-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    
    showToast('Commandes exportées en CSV', 'success');
}

// ================================
// DEBUG ET DÉVELOPPEMENT
// ================================

// Fonction pour ajouter des données de test
function addTestData() {
    // Ajouter quelques véhicules de test
    const testVehicles = [
        { brand: 'Test', model: 'Vehicle 1', year_from: 2020, year_to: 2024, engine: '1.0L', fuel_type: 'Essence' },
        { brand: 'Test', model: 'Vehicle 2', year_from: 2018, year_to: 2023, engine: '1.5L', fuel_type: 'Diesel' }
    ];
    
    // Ajouter quelques pièces de test
    const testParts = [
        {
            name: 'Pièce de test 1',
            sku: 'TEST-001',
            category: 'Test',
            price: 50.00,
            stock: 10,
            brand: 'TestBrand',
            description: 'Pièce pour les tests',
            oe_references: ['TESTREF1', 'TESTREF2']
        }
    ];
    
    console.log('Données de test:', { vehicles: testVehicles, parts: testParts });
}

// ================================
// GESTION DES FORMULAIRES VÉHICULES (NOUVELLES FONCTIONNALITÉS)
// ================================

// Charger les marques pour le formulaire
async function loadBrandsForForm() {
    const brandSelect = document.getElementById('vehicleBrand');
    const brands = [...new Set(vehicles.map(v => v.brand))].sort();
    
    brandSelect.innerHTML = '<option value="">Sélectionner ou créer</option>' +
        brands.map(brand => `<option value="${brand}">${brand}</option>`).join('') +
        '<option value="__new__">➕ Nouvelle marque</option>';
}

// Charger les modèles pour une marque
async function loadModelsForBrand() {
    const brandSelect = document.getElementById('vehicleBrand');
    const brandNewInput = document.getElementById('vehicleBrandNew');
    const modelSelect = document.getElementById('vehicleModel');
    const modelNewInput = document.getElementById('vehicleModelNew');
    
    const selectedBrand = brandSelect.value;
    
    if (selectedBrand === '__new__') {
        brandSelect.style.display = 'none';
        brandNewInput.style.display = 'block';
        brandNewInput.required = true;
        return;
    } else {
        brandSelect.style.display = 'block';
        brandNewInput.style.display = 'none';
        brandNewInput.required = false;
    }
    
    if (selectedBrand) {
        const models = [...new Set(vehicles.filter(v => v.brand === selectedBrand).map(v => v.model))].sort();
        modelSelect.innerHTML = '<option value="">Sélectionner ou créer</option>' +
            models.map(model => `<option value="${model}">${model}</option>`).join('') +
            '<option value="__new__">➕ Nouveau modèle</option>';
    } else {
        modelSelect.innerHTML = '<option value="">Sélectionner ou créer</option>';
    }
}

// Charger les motorisations pour un véhicule existant
async function loadEnginesForVehicle() {
    const brandSelect = document.getElementById('vehicleBrand');
    const brand = brandSelect.value === '__new__' ? 
        document.getElementById('vehicleBrandNew').value : brandSelect.value;
    
    const modelSelect = document.getElementById('vehicleModel');
    const modelNewInput = document.getElementById('vehicleModelNew');
    const selectedModel = modelSelect.value;
    
    if (selectedModel === '__new__') {
        modelSelect.style.display = 'none';
        modelNewInput.style.display = 'block';
        modelNewInput.required = true;
        return;
    } else {
        modelSelect.style.display = 'block';
        modelNewInput.style.display = 'none';
        modelNewInput.required = false;
    }
    
    // Si on a un véhicule existant, pré-remplir les motorisations
    if (brand && selectedModel) {
        const existingVehicle = vehicles.find(v => v.brand === brand && v.model === selectedModel);
        if (existingVehicle && existingVehicle.engines.length > 0) {
            // Vider le container d'abord
            document.getElementById('enginesContainer').innerHTML = '';
            // Ajouter les motorisations existantes
            existingVehicle.engines.forEach(engine => {
                addEngineField(engine.engine, engine.fuel_type);
            });
        }
    }
}

// Ajouter un champ de motorisation
function addEngineField(engineValue = '', fuelValue = '') {
    const container = document.getElementById('enginesContainer');
    const engineIndex = container.children.length;
    
    const engineField = document.createElement('div');
    engineField.className = 'engine-field';
    engineField.innerHTML = `
        <div style="flex: 2;">
            <label>Motorisation</label>
            <input type="text" placeholder="ex: 1.2L" value="${engineValue}" required>
        </div>
        <div style="flex: 1;">
            <label>Carburant</label>
            <select required>
                <option value="">Sélectionner</option>
                <option value="Essence" ${fuelValue === 'Essence' ? 'selected' : ''}>Essence</option>
                <option value="Diesel" ${fuelValue === 'Diesel' ? 'selected' : ''}>Diesel</option>
                <option value="GPL" ${fuelValue === 'GPL' ? 'selected' : ''}>GPL</option>
                <option value="Hybride" ${fuelValue === 'Hybride' ? 'selected' : ''}>Hybride</option>
                <option value="Électrique" ${fuelValue === 'Électrique' ? 'selected' : ''}>Électrique</option>
            </select>
        </div>
        <div>
            <button type="button" class="btn-remove" onclick="removeEngineField(this)">🗑️</button>
        </div>
    `;
    
    container.appendChild(engineField);
}

// Supprimer un champ de motorisation
function removeEngineField(button) {
    const container = document.getElementById('enginesContainer');
    if (container.children.length > 1) {
        button.parentElement.parentElement.remove();
    } else {
        showToast('Au moins une motorisation est requise', 'warning');
    }
}

// Modifier la fonction saveVehicle
async function saveVehicle() {
    const form = document.getElementById('vehicleForm');
    const brandSelect = document.getElementById('vehicleBrand');
    const brandNewInput = document.getElementById('vehicleBrandNew');
    const modelSelect = document.getElementById('vehicleModel');
    const modelNewInput = document.getElementById('vehicleModelNew');
    
    const brand = brandSelect.value === '__new__' ? brandNewInput.value.trim() : brandSelect.value;
    const model = modelSelect.value === '__new__' ? modelNewInput.value.trim() : modelSelect.value;
    
    // Validation
    if (!brand || !model) {
        showToast('Marque et modèle sont obligatoires', 'error');
        return;
    }
    
    // Récupérer les motorisations
    const engineFields = document.querySelectorAll('#enginesContainer .engine-field');
    const engines = [];
    
    engineFields.forEach(field => {
        const engineInput = field.querySelector('input[type="text"]');
        const fuelSelect = field.querySelector('select');
        
        const engine = engineInput.value.trim();
        const fuel = fuelSelect.value;
        
        if (engine && fuel) {
            engines.push({ engine, fuel_type: fuel });
        }
    });
    
    if (engines.length === 0) {
        showToast('Au moins une motorisation est requise', 'error');
        return;
    }
    
    const vehicleId = document.getElementById('vehicleId').value;
    const year_from = document.getElementById('vehicleYearFrom').value ? 
        parseInt(document.getElementById('vehicleYearFrom').value) : null;
    const year_to = document.getElementById('vehicleYearTo').value ? 
        parseInt(document.getElementById('vehicleYearTo').value) : null;
    
    const formData = {
        brand,
        model,
        year_from,
        year_to,
        engines
    };
    
    try {
        const method = vehicleId ? 'PUT' : 'POST';
        const url = vehicleId ? 
            `${API_BASE_URL}/api/vehicles/${vehicleId}` : 
            `${API_BASE_URL}/api/vehicles`;
        
        const response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            showToast(result.message || 'Véhicule sauvegardé avec succès', 'success');
            closeModal('vehicleModal');
            await loadVehicles();
            updateVehicleFilters();
        } else {
            showToast(result.error || 'Erreur lors de la sauvegarde', 'error');
        }
    } catch (error) {
        console.error('Erreur sauvegarde véhicule:', error);
        showToast('Erreur de connexion', 'error');
    }
}

// Modifier l'initialisation des champs de motorisation
function initializeVehicleForm() {
    const container = document.getElementById('enginesContainer');
    if (container.children.length === 0) {
        addEngineField();
    }
}

// Fonction pour éditer un véhicule existant
function editVehicle(vehicle) {
    document.getElementById('vehicleId').value = vehicle.id;
    document.getElementById('vehicleBrand').value = vehicle.brand;
    document.getElementById('vehicleBrand').dispatchEvent(new Event('change'));
    
    setTimeout(() => {
        document.getElementById('vehicleModel').value = vehicle.model;
        document.getElementById('vehicleModel').dispatchEvent(new Event('change'));
    }, 100);
    
    document.getElementById('vehicleYearFrom').value = vehicle.year_from || '';
    document.getElementById('vehicleYearTo').value = vehicle.year_to || '';
    
    // Vider et ajouter les motorisations
    document.getElementById('enginesContainer').innerHTML = '';
    vehicle.engines.forEach(engine => {
        addEngineField(engine.engine, engine.fuel_type);
    });
    
    openModal('vehicleModal');
}

// ================================
// GESTION DES FORMULAIRES PIÈCES (NOUVELLE FONCTIONNALITÉ)
// ================================

// Modifier la fonction savePart pour inclure la sélection de véhicules
async function savePart() {
    const partId = document.getElementById('partId').value;
    const name = document.getElementById('partName').value.trim();
    const sku = document.getElementById('partSku').value.trim();
    const category = document.getElementById('partCategory').value;
    const price = parseFloat(document.getElementById('partPrice').value);
    const description = document.getElementById('partDescription').value.trim();
    const stock = parseInt(document.getElementById('partStock').value);
    const brand = document.getElementById('partBrand').value.trim();
    const image_url = document.getElementById('partImageUrl').value.trim();
    
    // Validation
    if (!name || !sku || !category || isNaN(price) || isNaN(stock)) {
        showToast('Veuillez remplir tous les champs obligatoires', 'error');
        return;
    }
    
    // Récupérer les références OE depuis le champ texte existant
    const oeReferencesText = document.getElementById('partOeReferences').value.trim();
    const oeReferences = oeReferencesText ? 
        oeReferencesText.split(',').map(ref => ref.trim()).filter(ref => ref) : [];
    
    // Récupérer les véhicules sélectionnés
    const selectedVehicleIds = [];
    document.querySelectorAll('input[name="compatibleVehicles"]:checked').forEach(checkbox => {
        selectedVehicleIds.push(parseInt(checkbox.value));
    });
    
    const formData = {
        name,
        sku,
        category,
        price,
        description,
        stock,
        brand,
        image_url,
        oe_references: oeReferences,
        vehicle_ids: selectedVehicleIds
    };
    
    try {
        const method = partId ? 'PUT' : 'POST';
        const url = partId ? 
            `${API_BASE_URL}/api/parts/${partId}` : 
            `${API_BASE_URL}/api/parts`;
        
        const response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            showToast(result.message || 'Pièce sauvegardée avec succès', 'success');
            closeModal('partModal');
            await loadParts();
        } else {
            showToast(result.error || 'Erreur lors de la sauvegarde', 'error');
        }
    } catch (error) {
        console.error('Erreur sauvegarde pièce:', error);
        showToast('Erreur de connexion', 'error');
    }
}

// ================================
// GESTION DE LA SÉLECTION VÉHICULES DANS FORMULAIRE PIÈCES
// ================================

// Gérer les champs OE References dynamiques
function addOeReferenceField(value = '') {
    const container = document.getElementById('oeReferencesContainer');
    const fieldIndex = container.children.length;
    
    const fieldDiv = document.createElement('div');
    fieldDiv.className = 'oe-reference-field';
    fieldDiv.innerHTML = `
        <input type="text" class="oe-reference" placeholder="Référence OE" value="${value}">
        <button type="button" class="btn-remove" onclick="removeOeReferenceField(this)">🗑️</button>
    `;
    
    container.appendChild(fieldDiv);
}

function removeOeReferenceField(button) {
    const container = document.getElementById('oeReferencesContainer');
    if (container.children.length > 1) {
        button.parentElement.remove();
    } else {
        button.previousElementSibling.value = '';
    }
}

// Afficher/masquer le sélecteur de véhicules
function toggleVehicleSelector() {
    const checkbox = document.getElementById('showVehicleSelector');
    const container = document.getElementById('vehicleSelectorContainer');
    
    if (checkbox.checked) {
        container.style.display = 'block';
        loadCompatibleVehicles();
    } else {
        container.style.display = 'none';
    }
}

// Charger la liste des véhicules pour sélection
function loadCompatibleVehicles() {
    const vehicleList = document.getElementById('vehicleList');
    if (!vehicleList) return;
    
    // Grouper par marque
    const brands = [...new Set(vehicles.map(v => v.brand))].sort();
    let html = '';
    
    brands.forEach(brand => {
        const brandVehicles = vehicles.filter(v => v.brand === brand);
        
        html += `<div class="vehicle-category">`;
        html += `<div class="vehicle-category-title">🚗 ${brand}</div>`;
        
        brandVehicles.forEach(vehicle => {
            html += `<div class="vehicle-item">`;
            html += `<input type="checkbox" id="vehicle_${vehicle.id}" name="compatibleVehicles" value="${vehicle.id}">`;
            html += `<label for="vehicle_${vehicle.id}" class="vehicle-info">`;
            html += `<strong>${vehicle.model}</strong> (${vehicle.year_from || '?'}-${vehicle.year_to || '?'})`;
            html += `<div class="vehicle-engines">`;
            html += vehicle.engines.map(e => `${e.engine} ${e.fuel_type}`).join(', ');
            html += `</div>`;
            html += `</label>`;
            html += `</div>`;
        });
        
        html += `</div>`;
    });
    
    vehicleList.innerHTML = html;
}

// Modifier les fonctions addPart et editPart pour initialiser la sélection véhicules
function addPart() {
    document.getElementById('partModalTitle').textContent = 'Nouvelle Pièce';
    document.getElementById('partForm').reset();
    document.getElementById('partId').value = '';
    
    // Réinitialiser la sélection véhicules
    document.getElementById('showVehicleSelector').checked = false;
    document.getElementById('vehicleSelectorContainer').style.display = 'none';
    
    // Vider le sélecteur de véhicules
    const vehicleList = document.getElementById('vehicleList');
    if (vehicleList) {
        vehicleList.innerHTML = '';
    }
    
    showModal('partModal');
}

function editPart(part) {
    document.getElementById('partModalTitle').textContent = 'Modifier Pièce';
    document.getElementById('partId').value = part.id;
    document.getElementById('partName').value = part.name || '';
    document.getElementById('partSku').value = part.sku || '';
    document.getElementById('partCategory').value = part.category || '';
    document.getElementById('partPrice').value = part.price || '';
    document.getElementById('partStock').value = part.stock || '';
    document.getElementById('partBrand').value = part.brand || '';
    document.getElementById('partImageUrl').value = part.image_url || '';
    document.getElementById('partDescription').value = part.description || '';
    
    // Références OE
    const oeReferences = part.oe_references || [];
    if (oeReferences.length > 0) {
        document.getElementById('partOeReferences').value = oeReferences.join(',');
    } else {
        document.getElementById('partOeReferences').value = '';
    }
    
    // Réinitialiser la sélection véhicules
    document.getElementById('showVehicleSelector').checked = false;
    document.getElementById('vehicleSelectorContainer').style.display = 'none';
    
    // Vider le sélecteur de véhicules
    const vehicleList = document.getElementById('vehicleList');
    if (vehicleList) {
        vehicleList.innerHTML = '';
    }
    
    showModal('partModal');
}

// Accessible globalement pour debugging
window.adminFunctions = {
    addTestData,
    loadStats,
    loadVehicles,
    loadParts,
    loadOrders,
    checkBackendConnection,
    showToast,
    exportData,
    // Nouvelles fonctions
    loadBrandsForForm,
    loadModelsForBrand,
    loadEnginesForVehicle,
    addEngineField,
    removeEngineField,
    saveVehicle,
    editVehicle,
    showVehicleSelector,
    loadCompatibleVehicles,
    savePart
};