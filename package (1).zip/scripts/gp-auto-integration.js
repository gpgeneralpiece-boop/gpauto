// GP AUTO - Exemples d'intégration Frontend vers Backend
// Remplacez votre logique JavaScript par ces appels API

// ================================
// 1. CONFIGURATION
// ================================

const API_BASE_URL = 'http://localhost:3001'; // En production: votre URL Vercel/Railway

// ================================
// 2. GESTION DES VÉHICULES
// ================================

// Charger les marques
async function loadVehicleBrands() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/vehicles`);
        const brands = await response.json();
        
        const brandSelect = document.getElementById('brandSelect');
        brandSelect.innerHTML = '<option value="">Sélectionner une marque</option>';
        
        brands.forEach(brand => {
            const option = document.createElement('option');
            option.value = brand.brand;
            option.textContent = brand.brand;
            brandSelect.appendChild(option);
        });
    } catch (error) {
        console.error('Erreur chargement marques:', error);
    }
}

// Charger les modèles selon la marque
async function loadVehicleModels(brand) {
    if (!brand) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/vehicles?brand=${encodeURIComponent(brand)}`);
        const models = await response.json();
        
        const modelSelect = document.getElementById('modelSelect');
        modelSelect.innerHTML = '<option value="">Sélectionner un modèle</option>';
        modelSelect.disabled = false;
        
        models.forEach(model => {
            const option = document.createElement('option');
            option.value = model.model;
            option.textContent = model.model;
            modelSelect.appendChild(option);
        });
    } catch (error) {
        console.error('Erreur chargement modèles:', error);
    }
}

// Charger les motorisations
async function loadEngines(brand, model) {
    if (!brand || !model) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/vehicles/engines?brand=${encodeURIComponent(brand)}&model=${encodeURIComponent(model)}`);
        const engines = await response.json();
        
        const engineSelect = document.getElementById('engineSelect');
        engineSelect.innerHTML = '<option value="">Sélectionner une motorisation</option>';
        engineSelect.disabled = false;
        
        engines.forEach(engine => {
            const option = document.createElement('option');
            option.value = `${engine.engine}-${engine.fuel_type}`;
            option.textContent = `${engine.engine} (${engine.fuel_type})`;
            engineSelect.appendChild(option);
        });
    } catch (error) {
        console.error('Erreur chargement motorisations:', error);
    }
}

// ================================
// 3. CATALOGUE DE PIÈCES
// ================================

// Charger les pièces par véhicule
async function loadPartsByVehicle(brand, model, engine) {
    if (!brand || !model || !engine) return;
    
    try {
        const [engineType, fuelType] = engine.split('-');
        const response = await fetch(`${API_BASE_URL}/api/parts/vehicle/${brand}/${model}/${engineType}`);
        const parts = await response.json();
        
        displayParts(parts);
    } catch (error) {
        console.error('Erreur chargement pièces:', error);
    }
}

// Charger les pièces par catégorie
async function loadPartsByCategory(category) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/parts/category/${encodeURIComponent(category)}`);
        const parts = await response.json();
        
        displayParts(parts);
    } catch (error) {
        console.error('Erreur chargement catégorie:', error);
    }
}

// Charger les catégories disponibles
async function loadCategories() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/categories`);
        const categories = await response.json();
        
        // Remplir le menu des catégories
        const categoryMenu = document.getElementById('categoryMenu');
        categoryMenu.innerHTML = '';
        
        categories.forEach(cat => {
            const button = document.createElement('button');
            button.className = 'category-btn';
            button.textContent = cat.category;
            button.onclick = () => loadPartsByCategory(cat.category);
            categoryMenu.appendChild(button);
        });
    } catch (error) {
        console.error('Erreur chargement catégories:', error);
    }
}

// ================================
// 4. RECHERCHE AVANCÉE
// ================================

let searchTimeout;

function handleSearchInput(event) {
    clearTimeout(searchTimeout);
    const query = event.target.value.trim();
    
    if (query.length < 2) {
        hideSearchResults();
        return;
    }
    
    searchTimeout = setTimeout(() => {
        performSearch(query);
    }, 300);
}

async function performSearch(query) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/search?query=${encodeURIComponent(query)}`);
        const results = await response.json();
        
        displaySearchResults(results);
    } catch (error) {
        console.error('Erreur recherche:', error);
    }
}

function displaySearchResults(results) {
    const searchResults = document.getElementById('searchResults');
    searchResults.innerHTML = '';
    
    if (results.length === 0) {
        searchResults.innerHTML = '<p class="no-results">Aucun résultat trouvé</p>';
        return;
    }
    
    results.forEach(part => {
        const partCard = createPartCard(part);
        searchResults.appendChild(partCard);
    });
    
    searchResults.style.display = 'block';
}

function hideSearchResults() {
    const searchResults = document.getElementById('searchResults');
    searchResults.style.display = 'none';
}

// ================================
// 5. GESTION DU PANIER
// ================================

// Ajouter au panier avec prix en temps réel
function addToCart(part, quantity = 1) {
    const cart = getCart();
    const existingItem = cart.find(item => item.sku === part.sku);
    
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        cart.push({
            sku: part.sku,
            name: part.name,
            price: part.price,
            quantity: quantity,
            image_url: part.image_url
        });
    }
    
    saveCart(cart);
    updateCartDisplay();
    showAddedToCartMessage(part.name);
}

// Calculer le total avec livraison
function calculateCartTotal() {
    const cart = getCart();
    const subtotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    
    // Configuration de livraison (à adapter selon vos besoins)
    const DELIVERY_CONFIG = {
        FREE_DELIVERY_THRESHOLD: 200,
        DELIVERY_FEE: 5,
        FREE_DELIVERY_MESSAGE: 'Livraison gratuite !'
    };
    
    const deliveryFee = subtotal >= DELIVERY_CONFIG.FREE_DELIVERY_THRESHOLD ? 0 : DELIVERY_CONFIG.DELIVERY_FEE;
    const total = subtotal + deliveryFee;
    
    return {
        subtotal,
        deliveryFee,
        total,
        isFreeDelivery: deliveryFee === 0
    };
}

// ================================
// 6. COMMANDE ET CHECKOUT
// ================================

// Créer une commande
async function createOrder(orderData) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/orders`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(orderData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccessMessage(`🎉 Commande #${result.order_id} créée avec succès !`);
            clearCart();
            updateCartDisplay();
            
            // Optionnel: Afficher les détails de la commande
            showOrderDetails(result.order_id);
            
            return result;
        } else {
            showErrorMessage('Erreur lors de la création de la commande');
            return null;
        }
    } catch (error) {
        console.error('Erreur création commande:', error);
        showErrorMessage('Problème de connexion avec le serveur');
        return null;
    }
}

// Obtenir les détails d'une commande
async function getOrderDetails(orderId) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/orders/${orderId}`);
        const order = await response.json();
        
        return order;
    } catch (error) {
        console.error('Erreur récupération commande:', error);
        return null;
    }
}

// Soumettre le formulaire de commande
async function submitOrderForm(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const orderData = {
        customer_name: formData.get('customerName'),
        phone: formData.get('phone'),
        address: formData.get('address'),
        delivery_mode: formData.get('deliveryMode'),
        items: getCart(),
        ...calculateCartTotal()
    };
    
    // Validation côté client
    if (!orderData.customer_name || !orderData.phone) {
        showErrorMessage('Veuillez remplir tous les champs obligatoires');
        return;
    }
    
    if (orderData.delivery_mode === 'livraison' && !orderData.address) {
        showErrorMessage('L\'adresse est obligatoire pour la livraison');
        return;
    }
    
    // Désactiver le bouton pendant le traitement
    const submitButton = event.target.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    submitButton.textContent = 'Traitement en cours...';
    
    const result = await createOrder(orderData);
    
    // Réactiver le bouton
    submitButton.disabled = false;
    submitButton.textContent = 'Confirmer la commande';
    
    if (result) {
        event.target.reset();
        hideAddressField(); // Cacher le champ adresse si nécessaire
    }
}

// ================================
// 7. UTILITAIRES ET UI
// ================================

// Créer une carte de pièce
function createPartCard(part) {
    const card = document.createElement('div');
    card.className = 'part-card';
    
    card.innerHTML = `
        <img src="${part.image_url}" alt="${part.name}" class="part-image">
        <div class="part-info">
            <h3 class="part-name">${part.name}</h3>
            <p class="part-sku">SKU: ${part.sku}</p>
            <p class="part-brand">${part.brand}</p>
            ${part.oe_references && part.oe_references.length > 0 ? 
                `<p class="oe-references">OE: ${part.oe_references.slice(0, 3).join(', ')}${part.oe_references.length > 3 ? '...' : ''}</p>` : ''
            }
            <p class="part-price">${part.price.toFixed(2)} TND</p>
            <div class="part-actions">
                <button onclick="addToCart(${JSON.stringify(part).replace(/"/g, '&quot;')})" class="add-to-cart-btn">
                    Ajouter au panier
                </button>
                <button onclick="viewPartDetails('${part.sku}')" class="view-details-btn">
                    Détails
                </button>
            </div>
        </div>
    `;
    
    return card;
}

// Afficher les pièces dans le catalogue
function displayParts(parts) {
    const catalog = document.getElementById('catalog');
    catalog.innerHTML = '';
    
    if (parts.length === 0) {
        catalog.innerHTML = '<p class="no-parts">Aucune pièce disponible pour cette sélection</p>';
        return;
    }
    
    parts.forEach(part => {
        const card = createPartCard(part);
        catalog.appendChild(card);
    });
}

// Messages utilisateur
function showSuccessMessage(message) {
    showMessage(message, 'success');
}

function showErrorMessage(message) {
    showMessage(message, 'error');
}

function showMessage(message, type) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.textContent = message;
    
    document.body.appendChild(messageDiv);
    
    setTimeout(() => {
        messageDiv.remove();
    }, 5000);
}

// Gestion du panier (localStorage)
function getCart() {
    const cart = localStorage.getItem('gpauto_cart');
    return cart ? JSON.parse(cart) : [];
}

function saveCart(cart) {
    localStorage.setItem('gpauto_cart', JSON.stringify(cart));
}

function clearCart() {
    localStorage.removeItem('gpauto_cart');
}

// ================================
// 8. INITIALISATION
// ================================

// Initialisation au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
    // Charger les données de base
    loadVehicleBrands();
    loadCategories();
    
    // Configurer les event listeners
    const brandSelect = document.getElementById('brandSelect');
    if (brandSelect) {
        brandSelect.addEventListener('change', (e) => {
            loadVehicleModels(e.target.value);
            document.getElementById('modelSelect').innerHTML = '<option value="">Sélectionner un modèle</option>';
            document.getElementById('engineSelect').innerHTML = '<option value="">Sélectionner une motorisation</option>';
        });
    }
    
    const modelSelect = document.getElementById('modelSelect');
    if (modelSelect) {
        modelSelect.addEventListener('change', (e) => {
            const brand = document.getElementById('brandSelect').value;
            loadEngines(brand, e.target.value);
            document.getElementById('engineSelect').innerHTML = '<option value="">Sélectionner une motorisation</option>';
        });
    }
    
    const engineSelect = document.getElementById('engineSelect');
    if (engineSelect) {
        engineSelect.addEventListener('change', (e) => {
            const brand = document.getElementById('brandSelect').value;
            const model = document.getElementById('modelSelect').value;
            loadPartsByVehicle(brand, model, e.target.value);
        });
    }
    
    // Gestion de la recherche
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', handleSearchInput);
    }
    
    // Gestion du formulaire de commande
    const orderForm = document.getElementById('orderForm');
    if (orderForm) {
        orderForm.addEventListener('submit', submitOrderForm);
    }
    
    // Gestion du mode de livraison
    const deliveryModeRadios = document.querySelectorAll('input[name="deliveryMode"]');
    deliveryModeRadios.forEach(radio => {
        radio.addEventListener('change', (e) => {
            toggleAddressField(e.target.value);
        });
    });
    
    // Initialiser l'affichage du panier
    updateCartDisplay();
});

// Gestion de l'affichage conditionnel de l'adresse
function toggleAddressField(deliveryMode) {
    const addressField = document.getElementById('addressField');
    if (addressField) {
        addressField.style.display = deliveryMode === 'livraison' ? 'block' : 'none';
    }
}

// ================================
// 9. FONCTIONS D'AIDE
// ================================

// Charger les statistiques (pour l'admin)
async function loadStats() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/stats`);
        const stats = await response.json();
        console.log('Statistiques GP AUTO:', stats);
        return stats;
    } catch (error) {
        console.error('Erreur chargement stats:', error);
        return null;
    }
}

// Vérifier la santé du backend
async function checkBackendHealth() {
    try {
        const response = await fetch(`${API_BASE_URL}/api/health`);
        const health = await response.json();
        
        if (health.status === 'OK') {
            console.log('✅ Backend GP AUTO opérationnel');
            return true;
        } else {
            console.warn('⚠️ Problème backend:', health);
            return false;
        }
    } catch (error) {
        console.error('❌ Backend inaccessible:', error);
        return false;
    }
}

// Gestion des erreurs réseau
function handleNetworkError(error) {
    console.error('Erreur réseau:', error);
    showErrorMessage('Problème de connexion. Vérifiez votre internet.');
}

// ================================
// EXPORTS (si usage modules)
// ================================
window.GPAutoAPI = {
    loadVehicleBrands,
    loadVehicleModels,
    loadEngines,
    loadPartsByVehicle,
    loadPartsByCategory,
    performSearch,
    addToCart,
    createOrder,
    getOrderDetails,
    calculateCartTotal,
    loadStats,
    checkBackendHealth
};

// Utilisation dans votre HTML:
// <script src="gp-auto-integration.js"></script>
// <script>
//   GPAutoAPI.loadVehicleBrands();
// </script>