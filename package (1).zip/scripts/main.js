// Données des véhicules et pièces (en production, ces données viendraient d'une API)
const vehicleData = {
    'Peugeot': {
        '206': ['1.4L HDI', '1.6L 16V', '2.0L 16V'],
        '207': ['1.4L HDI', '1.6L 16V', '1.6L THP'],
        '307': ['1.4L HDI', '1.6L 16V', '2.0L HDI'],
        '308': ['1.2L PureTech', '1.6L HDI', '1.6L THP']
    },
    'Renault': {
        'Clio': ['1.2L 16V', '1.5L dCi', '1.6L 16V'],
        'Mégane': ['1.4L 16V', '1.5L dCi', '2.0L 16V'],
        'Scenic': ['1.5L dCi', '1.6L 16V', '2.0L dCi'],
        'Captur': ['0.9L TCe', '1.2L TCe', '1.5L dCi']
    },
    'Volkswagen': {
        'Golf': ['1.4L TSI', '1.6L TDI', '2.0L TDI'],
        'Polo': ['1.0L MPI', '1.2L TSI', '1.4L TDI'],
        'Tiguan': ['1.4L TSI', '2.0L TSI', '2.0L TDI'],
        'Passat': ['1.4L TSI', '1.8L TSI', '2.0L TDI']
    },
    'BMW': {
        'Série 1': ['1.6L N46', '2.0L N46', '3.0L N52'],
        'Série 3': ['2.0L N46', '2.5L N52', '3.0L N54'],
        'X1': ['2.0L N46', '2.0L N57', '3.0L N54'],
        'X3': ['2.0L N46', '3.0L N52', '3.0L N57']
    },
    'Tunisie Populaires': {
        'Dacia Logan': ['1.4L 8V', '1.6L 16V', '1.5L dCi'],
        'Dacia Sandero': ['1.2L 16V', '1.5L dCi', '0.9L TCe'],
        'Dacia Duster': ['1.6L 16V', '1.5L dCi', '1.2L TCe'],
        'Renault Clio Tunisia': ['1.2L 16V', '1.5L dCi', '1.6L 16V'],
        'Peugeot 208 Tunisia': ['1.2L PureTech', '1.6L HDI', '1.2L VTi'],
        'Citroën C3 Tunisia': ['1.2L PureTech', '1.6L HDI', '1.4L VTi']
    }
};

// Catégories de pièces avec leurs mots-clés pour l'import d'images
const partCategories = {
    'motor': {
        name: 'Moteur',
        keywords: ['piece auto moteur', 'filter huile', 'bougie allumage', 'courroie distribution'],
        parts: [
            { name: 'Filtre à huile', sku: 'FO-001', oeReferences: ['1201E7', '1567A4'], price: 47.97 },
            { name: 'Bougie d\'allumage', sku: 'BA-002', oeReferences: ['5960F6', '5962C6'], price: 37.50 },
            { name: 'Courroie de distribution', sku: 'CD-003', oeReferences: ['0839K7', '5751G2'], price: 269.97 },
            { name: 'Pompe à eau', sku: 'PA-004', oeReferences: ['1351A9', '1336V7'], price: 375.00 },
            { name: 'Joint de culasse', sku: 'JC-005', oeReferences: ['0249L5', '0249K6'], price: 137.25 }
        ]
    },
    'brake': {
        name: 'Freinage',
        keywords: ['plaquette frein', 'disque frein', 'liquide frein', 'etrier frein'],
        parts: [
            { name: 'Plaquettes de frein avant', sku: 'PF-001', oeReferences: ['1609253180', '1609253980'], price: 107.97 },
            { name: 'Disque de frein avant', sku: 'DF-002', oeReferences: ['1609253080', '1609253280'], price: 235.50 },
            { name: 'Liquide de frein DOT4', sku: 'LF-003', oeReferences: ['97R9V9'], price: 26.97 },
            { name: 'Étrier de frein', sku: 'EF-004', oeReferences: ['1348Q3', '1348S3'], price: 435.00 }
        ]
    },
    'suspension': {
        name: 'Suspension',
        keywords: ['amortisseur', 'ressort', 'rotule', 'silentbloc'],
        parts: [
            { name: 'Amortisseur avant', sku: 'AM-001', oeReferences: ['2231675', '2231705'], price: 257.97 },
            { name: 'Ressort suspension', sku: 'RS-002', oeReferences: ['2231685', '2231715'], price: 196.50 },
            { name: 'Rotule de suspension', sku: 'RT-003', oeReferences: ['1607203080', '1607203380'], price: 86.97 },
            { name: 'Silent bloc', sku: 'SB-004', oeReferences: ['1336W8', '1336Y8'], price: 47.25 }
        ]
    },
    'electric': {
        name: 'Électrique',
        keywords: ['batterie voiture', 'alternateur', 'demarreur', 'phare'],
        parts: [
            { name: 'Batterie 12V 60Ah', sku: 'BT-001', oeReferences: ['570500156', 'L5 60AH'], price: 287.97 },
            { name: 'Alternateur', sku: 'AL-002', oeReferences: ['571234567', '0120469029'], price: 856.50 },
            { name: 'Démarreur', sku: 'DM-003', oeReferences: ['432501567', '0001367010'], price: 467.97 },
            { name: 'Phare avant gauche', sku: 'PA-004', oeReferences: ['1608203180', '8E0941615'], price: 375.00 }
        ]
    },
    'body': {
        name: 'Carrosserie',
        keywords: ['pare-choc', 'capot', 'porte', 'retroviseur'],
        parts: [
            { name: 'Pare-chocs avant', sku: 'PC-001', oeReferences: ['1608193080', '4E0807221A'], price: 677.97 },
            { name: 'Capot moteur', sku: 'CM-002', oeReferences: ['1608264080', '4E0823059A'], price: 556.50 },
            { name: 'Rétroviseur droit', sku: 'RD-003', oeReferences: ['1608257080', '8E1858501A'], price: 137.97 },
            { name: 'Porte avant gauche', sku: 'PG-004', oeReferences: ['1608054080', '8E1833057A'], price: 945.00 }
        ]
    },
    'interior': {
        name: 'Intérieur',
        keywords: ['siege auto', 'volant', 'radio', 'tapisserie'],
        parts: [
            { name: 'Siège conducteur', sku: 'SC-001', oeReferences: ['1608152080', '5E0883057A'], price: 887.97 },
            { name: 'Volant cuir', sku: 'VL-002', oeReferences: ['1608201380', '4E0862531A'], price: 436.50 },
            { name: 'Autoradio Bluetooth', sku: 'AR-003', oeReferences: ['1E0035880A', '0570Q1'], price: 377.97 },
            { name: 'Tapis de sol', sku: 'TS-004', oeReferences: ['1608254080', '4E0061512'], price: 105.00 }
        ]
    }
};

// État global de l'application
let appState = {
    selectedVehicle: {
        brand: null,
        model: null,
        engine: null
    },
    cart: [],
    currentFilter: 'all',
    imageCache: new Map(),
    searchQuery: '',
    searchResults: null
};

// Éléments DOM
const elements = {
    brandSelect: document.getElementById('brandSelect'),
    modelSelect: document.getElementById('modelSelect'),
    engineSelect: document.getElementById('engineSelect'),
    searchBtn: document.getElementById('searchPartsBtn'),
    catalogSection: document.getElementById('catalogSection'),
    catalogGrid: document.getElementById('catalogGrid'),
    catalogTitle: document.getElementById('catalogTitle'),
    cartBtn: document.getElementById('cartBtn'),
    cartCount: document.getElementById('cartCount'),
    cartModal: document.getElementById('cartModal'),
    checkoutBtn: document.getElementById('checkoutBtn'),
    checkoutModal: document.getElementById('checkoutModal'),
    notification: document.getElementById('notification'),
    searchInput: document.getElementById('searchInput'),
    searchIconBtn: document.getElementById('searchIconBtn')
};

// Initialisation de l'application
function initApp() {
    populateBrandSelect();
    setupEventListeners();
    loadCartFromStorage();
}

// Remplir le select des marques
function populateBrandSelect() {
    elements.brandSelect.innerHTML = '<option value="">Sélectionnez une marque</option>';
    Object.keys(vehicleData).forEach(brand => {
        const option = document.createElement('option');
        option.value = brand;
        option.textContent = brand;
        elements.brandSelect.appendChild(option);
    });
}

// Configurer les écouteurs d'événements
function setupEventListeners() {
    // Sélecteur de véhicule
    elements.brandSelect.addEventListener('change', handleBrandChange);
    elements.modelSelect.addEventListener('change', handleModelChange);
    elements.engineSelect.addEventListener('change', handleEngineChange);
    elements.searchBtn.addEventListener('click', searchParts);
    
    // Barre de recherche
    elements.searchInput.addEventListener('input', handleSearchInput);
    elements.searchInput.addEventListener('keypress', handleSearchKeyPress);
    elements.searchIconBtn.addEventListener('click', handleSearchSubmit);
    
    // Panier
    elements.cartBtn.addEventListener('click', openCart);
    elements.checkoutBtn.addEventListener('click', openCheckout);
    
    // Modals
    document.getElementById('closeCart').addEventListener('click', closeModal);
    document.getElementById('closeCheckout').addEventListener('click', closeModal);
    document.getElementById('cartModal').addEventListener('click', closeModal);
    document.getElementById('checkoutModal').addEventListener('click', closeModal);
    
    // Checkout form
    document.getElementById('checkoutForm').addEventListener('submit', handleCheckout);
    document.getElementsByName('deliveryMode').forEach(radio => {
        radio.addEventListener('change', handleDeliveryModeChange);
    });
    
    // Filtres
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', handleFilterChange);
    });
}

// Gestion du changement de marque
function handleBrandChange() {
    const brand = elements.brandSelect.value;
    appState.selectedVehicle.brand = brand;
    
    // Réinitialiser les selects suivants
    elements.modelSelect.innerHTML = '<option value="">Sélectionnez un modèle</option>';
    elements.engineSelect.innerHTML = '<option value="">Sélectionnez une motorisation</option>';
    elements.engineSelect.disabled = true;
    elements.searchBtn.disabled = true;
    
    if (brand && vehicleData[brand]) {
        populateModelSelect(brand);
    }
    updateSearchButton();
}

// Remplir le select des modèles
function populateModelSelect(brand) {
    elements.modelSelect.innerHTML = '<option value="">Sélectionnez un modèle</option>';
    Object.keys(vehicleData[brand]).forEach(model => {
        const option = document.createElement('option');
        option.value = model;
        option.textContent = model;
        elements.modelSelect.appendChild(option);
    });
    elements.modelSelect.disabled = false;
}

// Gestion du changement de modèle
function handleModelChange() {
    const model = elements.modelSelect.value;
    appState.selectedVehicle.model = model;
    
    // Réinitialiser le select des motorisations
    elements.engineSelect.innerHTML = '<option value="">Sélectionnez une motorisation</option>';
    elements.searchBtn.disabled = true;
    
    if (model && vehicleData[appState.selectedVehicle.brand][model]) {
        populateEngineSelect(appState.selectedVehicle.brand, model);
    }
    updateSearchButton();
}

// Remplir le select des motorisations
function populateEngineSelect(brand, model) {
    elements.engineSelect.innerHTML = '<option value="">Sélectionnez une motorisation</option>';
    vehicleData[brand][model].forEach(engine => {
        const option = document.createElement('option');
        option.value = engine;
        option.textContent = engine;
        elements.engineSelect.appendChild(option);
    });
    elements.engineSelect.disabled = false;
}

// Gestion du changement de motorisation
function handleEngineChange() {
    appState.selectedVehicle.engine = elements.engineSelect.value;
    updateSearchButton();
}

// Mettre à jour l'état du bouton de recherche
function updateSearchButton() {
    const { brand, model, engine } = appState.selectedVehicle;
    elements.searchBtn.disabled = !brand || !model || !engine;
}

// Rechercher les pièces
async function searchParts() {
    const { brand, model, engine } = appState.selectedVehicle;
    
    if (!brand || !model || !engine) {
        showNotification('Veuillez sélectionner un véhicule complet', 'error');
        return;
    }
    
    // Afficher la section catalogue
    elements.catalogSection.style.display = 'block';
    elements.catalogTitle.textContent = `Pièces pour ${brand} ${model} ${engine}`;
    
    // Charger et afficher les pièces
    await loadParts();
    
    // Faire défiler vers le catalogue
    elements.catalogSection.scrollIntoView({ behavior: 'smooth' });
}

// Charger les pièces (simulation d'une API)
async function loadParts() {
    const allParts = [];
    
    // Générer des pièces pour chaque catégorie
    Object.entries(partCategories).forEach(([key, category]) => {
        category.parts.forEach(part => {
            allParts.push({
                ...part,
                category: key,
                categoryName: category.name,
                imageUrl: null, // Sera chargée via l'API Google Images
                inStock: Math.random() > 0.2 // 80% de chance d'être en stock
            });
        });
    });
    
    displayParts(allParts);
}

// Afficher les pièces dans la grille (avec ou sans recherche)
async function displayParts(parts) {
    // Si on a des résultats de recherche, les utiliser directement
    if (appState.searchResults) {
        displaySearchResults(appState.searchResults);
        return;
    }
    
    // Sinon, filtrer par catégorie comme avant
    const filteredParts = parts.filter(part => {
        if (appState.currentFilter === 'all') return true;
        return part.category === appState.currentFilter;
    });
    
    elements.catalogGrid.innerHTML = '';
    
    if (filteredParts.length === 0) {
        document.getElementById('noResults').style.display = 'block';
        return;
    } else {
        document.getElementById('noResults').style.display = 'none';
    }
    
    for (const part of filteredParts) {
        const productCard = await createProductCard(part);
        elements.catalogGrid.appendChild(productCard);
    }
}

// Créer une carte de produit
async function createProductCard(part) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.dataset.category = part.category;
    
    // Essayer de charger l'image automatiquement
    let imageUrl = appState.imageCache.get(part.sku);
    
    if (!imageUrl) {
        try {
            imageUrl = await searchPartImage(part.sku, part.name);
            if (imageUrl) {
                appState.imageCache.set(part.sku, imageUrl);
            }
        } catch (error) {
            console.error('Erreur lors du chargement de l\'image:', error);
        }
    }
    
    card.innerHTML = `
        <div class="product-image">
            ${imageUrl ? 
                `<img src="${imageUrl}" alt="${part.name}" loading="lazy">` : 
                '<div class="product-image-placeholder">🔧</div>'
            }
            ${part.inStock ? '<div class="stock-badge">En stock</div>' : ''}
        </div>
        <div class="product-category">${part.categoryName}</div>
        <div class="product-name">${part.name}</div>
        <div class="product-sku">Réf: ${part.sku}</div>
        <div class="product-price">${part.price.toFixed(2)} TND</div>
        <button class="add-to-cart-btn" data-sku="${part.sku}" data-name="${part.name}" data-price="${part.price}">
            Ajouter au panier
        </button>
    `;
    
    // Ajouter l'écouteur pour le bouton d'ajout au panier
    card.querySelector('.add-to-cart-btn').addEventListener('click', addToCart);
    
    return card;
}

// Rechercher une image via l'API Google Images (simulation)
async function searchPartImage(sku, partName) {
    // Dans un vrai projet, ceci utiliserait l'API Google Custom Search
    // Pour la démo, on simule avec quelques images d'exemple
    const mockImages = [
        'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=300&h=200&fit=crop',
        'https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=300&h=200&fit=crop',
        'https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=300&h=200&fit=crop',
        'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=300&h=200&fit=crop'
    ];
    
    // Simuler un délai de réseau
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Retourner une image aléatoire pour la démo
    return mockImages[Math.floor(Math.random() * mockImages.length)];
}

// Gérer les filtres (avec réinitialisation de recherche)
function handleFilterChange(event) {
    // Mettre à jour les boutons actifs
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    appState.currentFilter = event.target.dataset.filter;
    
    // Réinitialiser les résultats de recherche
    appState.searchResults = null;
    appState.searchQuery = '';
    elements.searchInput.value = '';
    
    // Recharger les pièces avec le nouveau filtre
    if (elements.catalogSection.style.display !== 'none') {
        loadParts();
    }
}

// Ajouter au panier
function addToCart(event) {
    const button = event.target;
    const part = {
        sku: button.dataset.sku,
        name: button.dataset.name,
        price: parseFloat(button.dataset.price),
        quantity: 1
    };
    
    // Vérifier si l'article est déjà dans le panier
    const existingItem = appState.cart.find(item => item.sku === part.sku);
    
    if (existingItem) {
        existingItem.quantity++;
    } else {
        appState.cart.push(part);
    }
    
    updateCartDisplay();
    saveCartToStorage();
    showNotification(`${part.name} ajouté au panier`);
    
    // Animation du bouton
    button.textContent = 'Ajouté !';
    button.style.background = '#198754';
    button.style.color = 'white';
    setTimeout(() => {
        button.textContent = 'Ajouter au panier';
        button.style.background = '';
        button.style.color = '';
    }, 1000);
}

// Mettre à jour l'affichage du panier
function updateCartDisplay() {
    const totalItems = appState.cart.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = appState.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    elements.cartCount.textContent = totalItems;
    document.getElementById('cartTotal').textContent = `${totalPrice.toFixed(2)} TND`;
    document.getElementById('subtotal').textContent = `${totalPrice.toFixed(2)} TND`;
    document.getElementById('finalTotal').textContent = `${totalPrice.toFixed(2)} TND`;
    
    // Mettre à jour les articles du panier
    const cartItems = document.getElementById('cartItems');
    cartItems.innerHTML = '';
    
    appState.cart.forEach(item => {
        const cartItem = createCartItem(item);
        cartItems.appendChild(cartItem);
    });
}

// Créer un article de panier
function createCartItem(item) {
    const cartItem = document.createElement('div');
    cartItem.className = 'cart-item';
    
    cartItem.innerHTML = `
        <div class="cart-item-image">
            ${appState.imageCache.get(item.sku) ? 
                `<img src="${appState.imageCache.get(item.sku)}" alt="${item.name}">` : 
                '<div style="color: #CED4DA; font-size: 24px;">🔧</div>'
            }
        </div>
        <div class="cart-item-details">
            <div class="cart-item-name">${item.name}</div>
            <div class="cart-item-sku">Réf: ${item.sku}</div>
            <div class="cart-item-controls">
                <button class="quantity-btn" onclick="updateQuantity('${item.sku}', -1)">-</button>
                <span class="quantity">${item.quantity}</span>
                <button class="quantity-btn" onclick="updateQuantity('${item.sku}', 1)">+</button>
                <span class="item-price">${(item.price * item.quantity).toFixed(2)} TND</span>
            </div>
        </div>
    `;
    
    return cartItem;
}

// Mettre à jour la quantité
function updateQuantity(sku, change) {
    const item = appState.cart.find(item => item.sku === sku);
    
    if (item) {
        item.quantity += change;
        
        if (item.quantity <= 0) {
            appState.cart = appState.cart.filter(item => item.sku !== sku);
        }
        
        updateCartDisplay();
        saveCartToStorage();
    }
}

// Ouvrir le panier
function openCart() {
    elements.cartModal.classList.add('active');
    updateCartDisplay();
}

// Ouvrir le checkout
function openCheckout() {
    if (appState.cart.length === 0) {
        showNotification('Votre panier est vide', 'error');
        return;
    }
    
    elements.cartModal.classList.remove('active');
    elements.checkoutModal.classList.add('active');
}

// Gestion du mode de livraison avec livraison gratuite
function handleDeliveryModeChange(event) {
    const deliveryAddress = document.getElementById('deliveryAddress');
    const deliveryFeeRow = document.getElementById('deliveryFeeRow');
    const finalTotal = document.getElementById('finalTotal');
    const deliveryFee = document.getElementById('deliveryFee');
    const subtotal = parseFloat(document.getElementById('subtotal').textContent);
    
    if (event.target.value === 'delivery') {
        deliveryAddress.style.display = 'block';
        
        // Calculer les frais de livraison
        const shippingFee = calculateDeliveryFee(subtotal, 'delivery');
        
        if (shippingFee === 0) {
            // Livraison gratuite
            deliveryFeeRow.style.display = 'flex';
            deliveryFee.textContent = DELIVERY_CONFIG.FREE_DELIVERY_MESSAGE;
            deliveryFee.style.color = '#198754'; // Vert pour livraison gratuite
            finalTotal.textContent = `${subtotal.toFixed(2)} TND`;
        } else {
            // Livraison payante
            deliveryFeeRow.style.display = 'flex';
            deliveryFee.textContent = `${shippingFee} TND`;
            deliveryFee.style.color = '#333333'; // Couleur normale
            finalTotal.textContent = `${(subtotal + shippingFee).toFixed(2)} TND`;
        }
    } else {
        // Retrait en magasin
        deliveryAddress.style.display = 'none';
        deliveryFeeRow.style.display = 'none';
        finalTotal.textContent = `${subtotal.toFixed(2)} TND`;
    }
}

// Gérer le checkout
function handleCheckout(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const orderData = {
        customer: {
            name: formData.get('customerName'),
            phone: formData.get('customerPhone'),
            address: formData.get('customerAddress'),
            deliveryDetails: formData.get('deliveryDetails') || ''
        },
        deliveryMode: formData.get('deliveryMode'),
        items: appState.cart,
        total: parseFloat(document.getElementById('finalTotal').textContent),
        orderDate: new Date().toISOString()
    };
    
    // Ici, vous Enverriez les données à votre API
    console.log('Données de commande:', orderData);
    
    // Simuler l'envoi de la commande
    setTimeout(() => {
        showNotification('Commande envoyée avec succès ! Nous vous contacterons bientôt.');
        appState.cart = [];
        updateCartDisplay();
        saveCartToStorage();
        closeModal();
        elements.checkoutModal.classList.remove('active');
        
        // Reset form
        event.target.reset();
        document.getElementById('deliveryAddress').style.display = 'none';
        document.getElementById('deliveryFeeRow').style.display = 'none';
    }, 1000);
}

// Fermer les modals
function closeModal(event) {
    if (event && event.target !== event.currentTarget) return;
    
    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.classList.remove('active');
    });
}

// Sauvegarder le panier dans localStorage
function saveCartToStorage() {
    localStorage.setItem('autoPartsCart', JSON.stringify(appState.cart));
}

// Charger le panier depuis localStorage
function loadCartFromStorage() {
    const savedCart = localStorage.getItem('autoPartsCart');
    if (savedCart) {
        appState.cart = JSON.parse(savedCart);
        updateCartDisplay();
    }
}

// Afficher une notification
function showNotification(message, type = 'success') {
    const notification = elements.notification;
    const notificationText = document.getElementById('notificationText');
    
    notificationText.textContent = message;
    notification.className = `notification ${type}`;
    notification.classList.add('show');
    
    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}

// === FONCTIONS DE RECHERCHE ===

// Gestion de l'input de recherche
function handleSearchInput(event) {
    appState.searchQuery = event.target.value.trim();
    
    // Si la recherche est vide, afficher tous les résultats
    if (appState.searchQuery === '') {
        appState.searchResults = null;
        if (elements.catalogSection.style.display !== 'none') {
            loadParts();
        }
    }
}

// Gestion de la touche Enter dans la recherche
function handleSearchKeyPress(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        handleSearchSubmit();
    }
}

// Soumettre la recherche
function handleSearchSubmit() {
    if (appState.searchQuery.trim() === '') {
        showNotification('Veuillez saisir un terme de recherche', 'error');
        return;
    }
    
    performSearch();
}

// Effectuer la recherche
function performSearch() {
    const query = appState.searchQuery.toLowerCase();
    const searchResults = [];
    
    // Rechercher dans toutes les pièces
    Object.entries(partCategories).forEach(([categoryKey, category]) => {
        category.parts.forEach(part => {
            const matchesName = part.name.toLowerCase().includes(query);
            const matchesSku = part.sku.toLowerCase().includes(query);
            const matchesOeReferences = part.oeReferences && part.oeReferences.some(ref => 
                ref.toLowerCase().includes(query)
            );
            
            if (matchesName || matchesSku || matchesOeReferences) {
                searchResults.push({
                    ...part,
                    category: categoryKey,
                    categoryName: category.name
                });
            }
        });
    });
    
    if (searchResults.length === 0) {
        showNotification('Aucune pièce trouvée pour votre recherche', 'error');
        return;
    }
    
    // Afficher les résultats
    elements.catalogSection.style.display = 'block';
    elements.catalogTitle.textContent = `Résultats de recherche pour "${appState.searchQuery}"`;
    appState.searchResults = searchResults;
    
    displaySearchResults(searchResults);
    elements.catalogSection.scrollIntoView({ behavior: 'smooth' });
    
    showNotification(`${searchResults.length} pièce(s) trouvée(s)`);
}

// Afficher les résultats de recherche
function displaySearchResults(parts) {
    elements.catalogGrid.innerHTML = '';
    
    for (const part of parts) {
        // Pas de filtrage par catégorie pour les résultats de recherche
        createProductCard(part).then(card => {
            elements.catalogGrid.appendChild(card);
        });
    }
    
    document.getElementById('noResults').style.display = 'none';
}

// === FONCTIONS DE LIVRAISON GRATUITE ===

// Constantes pour la livraison
const DELIVERY_CONFIG = {
    FREE_DELIVERY_THRESHOLD: 200, // Livraison gratuite à partir de 200 TND
    DELIVERY_FEE: 5, // Frais de livraison en TND
    FREE_DELIVERY_MESSAGE: 'Livraison gratuite !'
};

// Calculer les frais de livraison
function calculateDeliveryFee(totalAmount, deliveryMode) {
    if (deliveryMode === 'pickup') {
        return 0; // Retrait en magasin gratuit
    }
    
    if (deliveryMode === 'delivery') {
        if (totalAmount >= DELIVERY_CONFIG.FREE_DELIVERY_THRESHOLD) {
            return 0; // Livraison gratuite
        }
        return DELIVERY_CONFIG.DELIVERY_FEE;
    }
    
    return 0;
}

// Initialiser l'application quand le DOM est chargé
document.addEventListener('DOMContentLoaded', initApp);

// Fonctions globales pour les boutons de quantité (nécessaire pour les événements inline)
window.updateQuantity = updateQuantity;