// API d'Import Automatique d'Images pour Pièces Automobiles
// Ce fichier montre comment implémenter un système complet d'import d'images

class AutoPartsImageAPI {
    constructor(config = {}) {
        this.config = {
            googleApiKey: config.googleApiKey || '',
            googleCseId: config.googleCseId || '',
            supplierEndpoints: config.supplierEndpoints || {},
            cacheDuration: config.cacheDuration || 30 * 24 * 60 * 60 * 1000, // 30 jours
            maxRetries: config.maxRetries || 3,
            concurrentRequests: config.concurrentRequests || 3,
            ...config
        };
        
        this.requestQueue = [];
        this.runningRequests = 0;
        this.imageCache = new Map();
        this.initializeCache();
    }

    // Initialiser le cache depuis localStorage
    initializeCache() {
        const cached = localStorage.getItem('autoPartsImageCache');
        if (cached) {
            try {
                const cacheData = JSON.parse(cached);
                const now = Date.now();
                
                Object.entries(cacheData).forEach(([key, value]) => {
                    if (now - value.timestamp < this.config.cacheDuration) {
                        this.imageCache.set(key, value);
                    }
                });
            } catch (error) {
                console.warn('Erreur lors du chargement du cache:', error);
            }
        }
    }

    // Sauvegarder le cache dans localStorage
    saveCache() {
        const cacheObj = Object.fromEntries(this.imageCache);
        localStorage.setItem('autoPartsImageCache', JSON.stringify(cacheObj));
    }

    // Nettoyer les anciens éléments du cache
    cleanupCache() {
        const now = Date.now();
        for (const [key, value] of this.imageCache.entries()) {
            if (now - value.timestamp > this.config.cacheDuration) {
                this.imageCache.delete(key);
            }
        }
        this.saveCache();
    }

    // Rechercher une image par SKU avec fallback
    async searchImageBySKU(sku, partName, category = '') {
        // Vérifier le cache d'abord
        const cacheKey = this.generateCacheKey(sku, partName);
        if (this.imageCache.has(cacheKey)) {
            console.log(`Image trouvée en cache pour ${sku}`);
            return this.imageCache.get(cacheKey).url;
        }

        // Essayer différentes sources d'images
        const searchMethods = [
            () => this.searchGoogleImages(sku, partName),
            () => this.searchSupplierImages(sku, partName),
            () => this.searchByBarcode(sku),
            () => this.searchGenericAutoParts(partName, category)
        ];

        for (const method of searchMethods) {
            try {
                const imageUrl = await method();
                if (imageUrl) {
                    // Sauvegarder en cache
                    this.cacheImage(cacheKey, imageUrl);
                    return imageUrl;
                }
            } catch (error) {
                console.warn(`Échec de recherche pour ${sku}:`, error);
                continue;
            }
        }

        console.warn(`Aucune image trouvée pour ${sku} - ${partName}`);
        return null;
    }

    // Générer une clé de cache
    generateCacheKey(sku, partName) {
        return `${sku}_${partName.toLowerCase().replace(/\s+/g, '_')}`;
    }

    // Mettre en cache une image
    cacheImage(key, url) {
        this.imageCache.set(key, {
            url,
            timestamp: Date.now(),
            source: 'auto_import'
        });
        this.saveCache();
    }

    // Recherche via Google Custom Search API
    async searchGoogleImages(sku, partName) {
        if (!this.config.googleApiKey || !this.config.googleCseId) {
            throw new Error('Clés API Google non configurées');
        }

        const query = this.buildSearchQuery(sku, partName);
        const params = new URLSearchParams({
            key: this.config.googleApiKey,
            cx: this.config.googleCseId,
            q: query,
            searchType: 'image',
            num: '5',
            safe: 'active',
            imgSize: 'medium',
            imgType: 'photo'
        });

        const url = `https://www.googleapis.com/customsearch/v1?${params}`;
        
        const response = await fetch(url, {
            headers: {
                'User-Agent': 'AutoPartsImageAPI/1.0'
            }
        });

        if (!response.ok) {
            throw new Error(`Erreur API Google: ${response.status}`);
        }

        const data = await response.json();
        
        if (data.items && data.items.length > 0) {
            // Prendre la première image de haute qualité
            const bestImage = data.items.find(item => 
                item.image && item.image.height > 200 && item.image.width > 200
            ) || data.items[0];

            return bestImage.link;
        }

        return null;
    }

    // Construire une requête de recherche optimisée
    buildSearchQuery(sku, partName) {
        const keywords = [
            sku,
            partName,
            'pièce auto',
            'auto part',
            'automotive',
            'car part'
        ].filter(Boolean);

        return keywords.join(' ');
    }

    // Recherche via les APIs des fournisseurs
    async searchSupplierImages(sku, partName) {
        const results = await Promise.allSettled(
            Object.entries(this.config.supplierEndpoints).map(async ([name, endpoint]) => {
                return this.searchSupplierImage(name, endpoint, sku, partName);
            })
        );

        // Retourner la première image trouvée
        for (const result of results) {
            if (result.status === 'fulfilled' && result.value) {
                return result.value;
            }
        }

        return null;
    }

    // Recherche auprès d'un fournisseur spécifique
    async searchSupplierImage(supplierName, endpoint, sku, partName) {
        try {
            const url = `${endpoint}/images?sku=${encodeURIComponent(sku)}&name=${encodeURIComponent(partName)}`;
            
            const response = await fetch(url, {
                headers: {
                    'Authorization': `Bearer ${this.config.apiKey}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                const data = await response.json();
                if (data.imageUrl) {
                    console.log(`Image trouvée via ${supplierName} pour ${sku}`);
                    return data.imageUrl;
                }
            }
        } catch (error) {
            console.warn(`Erreur avec le fournisseur ${supplierName}:`, error);
        }

        return null;
    }

    // Recherche par code-barres (si disponible)
    async searchByBarcode(barcode) {
        if (!barcode || barcode.length < 8) {
            return null;
        }

        try {
            // API de recherche de produits par code-barres
            const response = await fetch(`https://api.barcodespider.com/v1/lookup?barcode=${barcode}`, {
                headers: {
                    'X-API-KEY': this.config.barcodeApiKey
                }
            });

            if (response.ok) {
                const data = await response.json();
                return data.images?.[0] || null;
            }
        } catch (error) {
            console.warn('Erreur lors de la recherche par code-barres:', error);
        }

        return null;
    }

    // Recherche générique pour pièces automobiles
    async searchGenericAutoParts(partName, category) {
        const categoryKeywords = {
            'motor': ['moteur', 'engine', 'filter', 'bougie'],
            'brake': ['frein', 'brake', 'plaquette', 'disque'],
            'suspension': ['suspension', 'amortisseur', 'ressort'],
            'electric': ['électrique', 'electric', 'batterie', 'alternateur'],
            'body': ['carrosserie', 'body', 'pare-choc', 'capot'],
            'interior': ['intérieur', 'interior', 'siège', 'volant']
        };

        const keywords = categoryKeywords[category] || ['auto', 'car', 'part'];
        const query = `${partName} ${keywords.join(' ')} image`;

        // Utiliser une API de recherche d'images générique
        return this.searchGenericImage(query);
    }

    // Recherche d'image générique (fallback)
    async searchGenericImage(query) {
        try {
            // Alternative: Unsplash API pour des images d'auto génériques
            const response = await fetch(`https://api.unsplash.com/search/photos?query=${encodeURIComponent(query)}&per_page=1`, {
                headers: {
                    'Authorization': `Client-ID ${this.config.unsplashAccessKey}`
                }
            });

            if (response.ok) {
                const data = await response.json();
                return data.results?.[0]?.urls?.small || null;
            }
        } catch (error) {
            console.warn('Erreur recherche générique:', error);
        }

        return null;
    }

    // Import en lot de plusieurs pièces
    async importBatch(parts) {
        const results = [];
        const batchSize = this.config.concurrentRequests;
        
        for (let i = 0; i < parts.length; i += batchSize) {
            const batch = parts.slice(i, i + batchSize);
            const batchPromises = batch.map(part => 
                this.searchImageBySKU(part.sku, part.name, part.category)
                    .then(imageUrl => ({ ...part, imageUrl }))
                    .catch(error => ({ ...part, imageUrl: null, error: error.message }))
            );
            
            const batchResults = await Promise.all(batchPromises);
            results.push(...batchResults);
            
            // Pause entre les lots pour respecter les limites d'API
            if (i + batchSize < parts.length) {
                await this.delay(1000);
            }
        }
        
        return results;
    }

    // Valider une URL d'image
    async validateImageUrl(url) {
        try {
            const response = await fetch(url, { method: 'HEAD' });
            return response.ok && response.headers.get('content-type')?.startsWith('image/');
        } catch (error) {
            return false;
        }
    }

    // Optimiser les images pour le web
    async optimizeImageUrl(originalUrl) {
        // Ajouter des paramètres pour optimiser l'affichage
        const url = new URL(originalUrl);
        
        // Pour Unsplash
        if (url.hostname.includes('unsplash.com')) {
            url.searchParams.set('w', '300');
            url.searchParams.set('h', '200');
            url.searchParams.set('fit', 'crop');
            url.searchParams.set('auto', 'format');
        }
        
        // Pour d'autres services...
        return url.toString();
    }

    // Générer des métadonnées SEO pour les images
    generateImageMetadata(partName, sku, category) {
        return {
            alt: `${partName} - Référence ${sku} | Pièces Auto Pro`,
            title: `${partName} (Réf: ${sku})`,
            loading: 'lazy',
            decoding: 'async',
            'data-category': category,
            'data-sku': sku
        };
    }

    // Utilitaires
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // Statistiques du cache
    getCacheStats() {
        const now = Date.now();
        const stats = {
            total: this.imageCache.size,
            fresh: 0,
            stale: 0
        };

        this.imageCache.forEach(value => {
            if (now - value.timestamp < this.config.cacheDuration) {
                stats.fresh++;
            } else {
                stats.stale++;
            }
        });

        return stats;
    }

    // Vider complètement le cache
    clearCache() {
        this.imageCache.clear();
        localStorage.removeItem('autoPartsImageCache');
        console.log('Cache d\'images vidé');
    }
}

// Configuration d'exemple
const imageAPIConfig = {
    googleApiKey: 'VOTRE_CLE_API_GOOGLE',
    googleCseId: 'VOTRE_ID_MOTEUR_RECHERCHE',
    supplierEndpoints: {
        'fournisseur1': 'https://api.fournisseur1.com',
        'fournisseur2': 'https://api.fournisseur2.com'
    },
    unsplashAccessKey: 'VOTRE_CLE_UNSPLASH',
    barcodeApiKey: 'VOTRE_CLE_BARCODE_API',
    cacheDuration: 30 * 24 * 60 * 60 * 1000, // 30 jours
    concurrentRequests: 3
};

// Export pour utilisation dans d'autres fichiers
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AutoPartsImageAPI;
} else {
    window.AutoPartsImageAPI = AutoPartsImageAPI;
    window.imageAPIConfig = imageAPIConfig;
}

// Exemple d'utilisation
/*
const imageAPI = new AutoPartsImageAPI(imageAPIConfig);

// Rechercher une image individuelle
const imageUrl = await imageAPI.searchImageBySKU('PF-001', 'Plaquettes de frein avant', 'brake');
console.log('URL de l\'image:', imageUrl);

// Import en lot
const parts = [
    { sku: 'PF-001', name: 'Plaquettes de frein avant', category: 'brake' },
    { sku: 'DF-002', name: 'Disque de frein avant', category: 'brake' },
    { sku: 'FO-003', name: 'Filtre à huile', category: 'motor' }
];

const results = await imageAPI.importBatch(parts);
console.log('Résultats:', results);

// Statistiques du cache
const stats = imageAPI.getCacheStats();
console.log('Statistiques du cache:', stats);
*/