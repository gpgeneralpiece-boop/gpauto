# Import Automatique d'Images pour Pièces Automobiles

## Vue d'ensemble

Le système d'import automatique d'images permet de récupérer automatiquement les images des pièces automobiles depuis Google Images en utilisant le SKU (référence) ou le code-barres des produits.

## Fonctionnalités Implémentées

### 1. Cache d'Images Intelligent
- **Mémorisation locale** : Les images sont sauvegardées dans le cache local du navigateur
- **Éviter les requêtes multiples** : Une image chargée une fois n'est plus rechargée
- **Performance optimisée** : Réduction du temps de chargement et de la bande passante

### 2. Recherche par SKU
```javascript
// Recherche automatique basée sur le SKU
const imageUrl = await searchPartImage('PF-001', 'Plaquettes de frein avant');
```

### 3. Intégration API Google Custom Search

## Configuration de l'API Google Custom Search

### Étape 1 : Créer un moteur de recherche programmable

1. Aller sur [Google Programmable Search Engine](https://cse.google.com)
2. Créer un nouveau moteur de recherche
3. Configurer pour rechercher dans les sites de pièces automobiles

### Étape 2 : Obtenir une clé API

1. Aller sur [Google Cloud Console](https://console.cloud.google.com)
2. Activer l'API Google Custom Search
3. Créer une clé API

### Étape 3 : Configuration dans le code

```javascript
// Configuration API Google
const GOOGLE_API_CONFIG = {
    apiKey: 'VOTRE_CLE_API',
    searchEngineId: 'VOTRE_ID_MOTEUR_RECHERCHE',
    baseUrl: 'https://www.googleapis.com/customsearch/v1'
};
```

### Étape 4 : Fonction d'import d'images

```javascript
async function searchPartImageReal(sku, partName) {
    const query = `${sku} ${partName} pièce automobile`;
    
    const params = new URLSearchParams({
        key: GOOGLE_API_CONFIG.apiKey,
        cx: GOOGLE_API_CONFIG.searchEngineId,
        q: query,
        searchType: 'image',
        num: 1,
        safe: 'active'
    });
    
    try {
        const response = await fetch(`${GOOGLE_API_CONFIG.baseUrl}?${params}`);
        const data = await response.json();
        
        if (data.items && data.items.length > 0) {
            return data.items[0].link;
        }
    } catch (error) {
        console.error('Erreur lors de la recherche d\'image:', error);
    }
    
    return null;
}
```

## Améliorations Possibles

### 1. Reconnaissance de Code-Barres
```javascript
// Utilisation de Google ML Kit pour scanner les codes-barres
async function scanBarcode(imageFile) {
    const { BarcodeDetector } = window;
    const detector = new BarcodeDetector({ formats: ['ean_13', 'code_128'] });
    const barcodes = await detector.detect(imageFile);
    return barcodes[0]?.rawValue;
}
```

### 2. Import depuis Base de Données Fournisseurs
```javascript
// Import depuis des APIs de fournisseurs
async function importFromSupplier(supplier, sku) {
    const endpoints = {
        'fournisseur1': `https://api.fournisseur1.com/images/${sku}`,
        'fournisseur2': `https://api.fournisseur2.com/search?sku=${sku}`
    };
    
    // Implémentation selon le fournisseur
}
```

### 3. Optimisation SEO des Images
```javascript
// Ajout de métadonnées alt optimisées
function optimizeImageMetadata(imageUrl, partName, sku) {
    return {
        src: imageUrl,
        alt: `${partName} - Référence ${sku} | Pièces Auto Pro`,
        loading: 'lazy',
        decoding: 'async'
    };
}
```

## Base de Données d'Images Locale

### Structure recommandée
```sql
CREATE TABLE product_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(50) UNIQUE NOT NULL,
    image_url TEXT NOT NULL,
    image_hash VARCHAR(64),
    source VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_sku (sku)
);
```

### Gestion du Cache
```javascript
// Nettoyage automatique du cache (30 jours)
function cleanupOldCache() {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    // Supprimer les images anciennes de la base de données
    // et du cache localStorage
}
```

## Sécurité et Conformité

### 1. Respect des Conditions d'Utilisation
- Utiliser l'API officielle Google Custom Search
- Respecter les quotas de requêtes (100 requêtes/jour gratuit)
- Ajouter un User-Agent approprié

### 2. Gestion des Droits d'Auteur
- Stocker uniquement les URLs, pas les images
- Vérifier les droits d'utilisation des images
- Mentionner la source des images

### 3. Rate Limiting
```javascript
// Limiter le nombre de requêtes simultanées
class ImageSearchQueue {
    constructor(maxConcurrent = 3) {
        this.maxConcurrent = maxConcurrent;
        this.running = 0;
        this.queue = [];
    }
    
    async search(sku, partName) {
        return new Promise((resolve, reject) => {
            this.queue.push({ sku, partName, resolve, reject });
            this.processQueue();
        });
    }
    
    async processQueue() {
        if (this.running >= this.maxConcurrent || this.queue.length === 0) return;
        
        const { sku, partName, resolve, reject } = this.queue.shift();
        this.running++;
        
        try {
            const result = await this.performSearch(sku, partName);
            resolve(result);
        } catch (error) {
            reject(error);
        } finally {
            this.running--;
            this.processQueue();
        }
    }
}
```

## Tests et Validation

### Tests Unitaires
```javascript
// Tests pour la fonction d'import d'images
describe('Image Import', () => {
    test('should find image by SKU', async () => {
        const imageUrl = await searchPartImage('PF-001', 'Plaquettes de frein');
        expect(imageUrl).toBeTruthy();
    });
    
    test('should return null for invalid SKU', async () => {
        const imageUrl = await searchPartImage('INVALID-SKU', 'Invalid Part');
        expect(imageUrl).toBeNull();
    });
});
```

### Tests d'Intégration
- Tester avec différents SKUs
- Vérifier la gestion des erreurs réseau
- Valider le performance du cache

## Monitoring et Analytics

### Métriques à Surveiller
- Taux de succès de recherche d'images
- Temps de réponse moyen
- Utilisation du cache vs requêtes réseau
- Volume de requêtes API

### Logs Recommandés
```javascript
function logImageSearch(sku, success, responseTime) {
    console.log(JSON.stringify({
        timestamp: new Date().toISOString(),
        sku,
        success,
        responseTime,
        source: 'google_custom_search'
    }));
}
```

## Conclusion

Ce système d'import automatique d'images offre une solution robuste et évolutive pour maintenir un catalogue visuel à jour des pièces automobiles. L'architecture modulaire permet d'ajouter facilement de nouveaux fournisseurs ou de modifier les stratégies de recherche selon les besoins.